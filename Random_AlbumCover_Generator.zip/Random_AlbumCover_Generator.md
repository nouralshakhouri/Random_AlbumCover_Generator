
# This is How to Randomly Generate Album Cover in 5 Easy Steps using Python and Jupyter Notebook

###  The purpose of this article is to demonstrate how to create randomly generated album cover using Python and Jupyter Notebook. The following is a summary of the steps used.

   1. Defining the required libraries
   2. Defining and learn how to use the display_cover function
   3. Using Wikipedia to load a random page
   4. Extracting the album and band titles from the page
   5. Displaying the generated album cover


---

## 1. Importing the Required Libraries


```python
from IPython.display import Image as IPythonImage
from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw
```

## 2. Defining and Learn How to Use the display_cover Function


```python
def display_cover(top,bottom ):
    """This fucntoin
    """
    import requests
    name='album_art_raw.png'
    # Now let's make get an album cover.
    # https://picsum.photos/ is a free service that offers random images.
    # Let's get a random image:
    album_art_raw = requests.get('https://picsum.photos/500/500/?random')
    # and save it as 'album_art_raw.png'
    with open(name,'wb') as album_art_raw_file:
       album_art_raw_file.write(album_art_raw.content)
    # Now that we have our raw image, let's open it 
    # and write our band and album name on it
    img = Image.open("album_art_raw.png")
    draw = ImageDraw.Draw(img)

    # We'll choose a font for our band and album title, 
    # run "% ls /usr/share/fonts/truetype/dejavu" in a cell to see what else is available,
    # or download your own .ttf fonts!
    band_name_font = ImageFont.truetype("DejaVuSans-Bold.ttf", 25) #25pt font
    album_name_font = ImageFont.truetype("DejaVuSans-Bold.ttf", 20) # 20pt font

    # the x,y coordinates for where our album name and band name text will start
    # counted from the top left of the picture (in pixels)
    band_x, band_y = 50, 50
    album_x, album_y = 50, 400

    # Our text should be visible on any image. A good way
    # of accomplishing that is to use white text with a 
    # black border. We'll use the technique shown here to draw the border:
    # https://mail.python.org/pipermail/image-sig/2009-May/005681.html
    outline_color ="black"
    draw.text((band_x-1, band_y-1), top, font=band_name_font, fill=outline_color)
    draw.text((band_x+1, band_y-1), top, font=band_name_font, fill=outline_color)
    draw.text((band_x-1, band_y+1), top, font=band_name_font, fill=outline_color)
    draw.text((band_x+1, band_y+1), top, font=band_name_font, fill=outline_color)
    draw.text((album_x-1, album_y-1), bottom , font=album_name_font, fill=outline_color)
    draw.text((album_x+1, album_y-1), bottom , font=album_name_font, fill=outline_color)
    draw.text((album_x-1, album_y+1), bottom , font=album_name_font, fill=outline_color)
    draw.text((album_x+1, album_y+1), bottom , font=album_name_font, fill=outline_color)
    draw.text((band_x,band_y),top,(255,255,255),font=band_name_font)
    draw.text((album_x, album_y),bottom,(255,255,255),font=album_name_font)

    return img
```

The function will randomly select an image from https://picsum.photos/ and will superimpose two variables over the image namely top and buttom. The below code shows how to use the helper cover and generate the image. The result is shown on the top of the page.


```python
# display the top and bottom text
img=display_cover(top='Nour S. Al-Shakhouri',bottom='Data Science')

# save the image file to sample-out.png
img.save('sample-out.png')

# read and display the image
IPythonImage(filename='sample-out.png')
```




![png](output_8_0.png)



## 3. Using Wikipedia to Load a Random Page


```python
# importing the requests librariy 
import requests

# defining the URL to random Wikipedia page and convert to a string
wikipedia_link='https://en.wikipedia.org/wiki/Special:Random'

# use get function adn requests libaray to download the Wikipedia page
# from the wikipedia_link and assign it to raw_random_wikipedia_page as
# raw XML
raw_random_wikipedia_page = requests.get(wikipedia_link)

# use the text data attribute to extract the XML as a text file and assign 
# it to page and print
page = raw_random_wikipedia_page.text
print(page)
```

    <!DOCTYPE html>
    <html class="client-nojs" lang="en" dir="ltr">
    <head>
    <meta charset="UTF-8"/>
    <title>European Climate Foundation - Wikipedia</title>
    <script>document.documentElement.className=document.documentElement.className.replace(/(^|\s)client-nojs(\s|$)/,"$1client-js$2");RLCONF={"wgCanonicalNamespace":"","wgCanonicalSpecialPageName":!1,"wgNamespaceNumber":0,"wgPageName":"European_Climate_Foundation","wgTitle":"European Climate Foundation","wgCurRevisionId":895409635,"wgRevisionId":895409635,"wgArticleId":30184825,"wgIsArticle":!0,"wgIsRedirect":!1,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":["Articles needing additional references from May 2015","All articles needing additional references","All stub articles","Europe stubs","Climate change organizations","Conservation organizations","Climate change in Europe","European Union and the environment"],"wgBreakFrames":!1,"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July",
    "August","September","October","November","December"],"wgMonthNamesShort":["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"wgRelevantPageName":"European_Climate_Foundation","wgRelevantArticleId":30184825,"wgRequestId":"XQ9KlgpAAEIAAH4RpKsAAADD","wgCSPNonce":!1,"wgIsProbablyEditable":!0,"wgRelevantPageIsProbablyEditable":!0,"wgRestrictionEdit":[],"wgRestrictionMove":[],"wgMediaViewerOnClick":!0,"wgMediaViewerEnabledByDefault":!0,"wgPopupsReferencePreviews":!1,"wgPopupsConflictsWithNavPopupGadget":!1,"wgVisualEditor":{"pageLanguageCode":"en","pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgMFDisplayWikibaseDescriptions":{"search":!0,"nearby":!0,"watchlist":!0,"tagline":!1},"wgWMESchemaEditAttemptStepOversample":!1,"wgPoweredByHHVM":!0,"wgULSCurrentAutonym":"English","wgNoticeProject":"wikipedia","wgCentralNoticeCategoriesUsingLegacy":["Fundraising","fundraising"],"wgWikibaseItemId":"Q5412382","wgCentralAuthMobileDomain":
    !1,"wgEditSubmitButtonLabelPublish":!0};RLSTATE={"ext.gadget.charinsert-styles":"ready","ext.globalCssJs.user.styles":"ready","ext.globalCssJs.site.styles":"ready","site.styles":"ready","noscript":"ready","user.styles":"ready","ext.globalCssJs.user":"ready","ext.globalCssJs.site":"ready","user":"ready","user.options":"ready","user.tokens":"loading","ext.cite.styles":"ready","mediawiki.legacy.shared":"ready","mediawiki.legacy.commonPrint":"ready","mediawiki.toc.styles":"ready","wikibase.client.init":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready","ext.uls.interlanguage":"ready","ext.wikimediaBadges":"ready","ext.3d.styles":"ready","mediawiki.skinning.interface":"ready","skins.vector.styles":"ready"};RLPAGEMODULES=["ext.cite.ux-enhancements","site","mediawiki.page.startup","mediawiki.page.ready","mediawiki.toc","mediawiki.searchSuggest","ext.gadget.teahouse","ext.gadget.ReferenceTooltips","ext.gadget.watchlist-notice","ext.gadget.DRN-wizard","ext.gadget.charinsert",
    "ext.gadget.refToolbar","ext.gadget.extra-toolbar-buttons","ext.gadget.switcher","ext.centralauth.centralautologin","mmv.head","mmv.bootstrap.autostart","ext.popups","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader","ext.eventLogging","ext.wikimediaEvents","ext.navigationTiming","ext.uls.compactlinks","ext.uls.interface","ext.quicksurveys.init","ext.centralNotice.geoIP","ext.centralNotice.startUp","skins.vector.js"];</script>
    <script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.tokens@0tffind",function($,jQuery,require,module){/*@nomin*/mw.user.tokens.set({"editToken":"+\\","patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});
    });});</script>
    <link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.3d.styles%7Cext.cite.styles%7Cext.uls.interlanguage%7Cext.visualEditor.desktopArticleTarget.noscript%7Cext.wikimediaBadges%7Cmediawiki.legacy.commonPrint%2Cshared%7Cmediawiki.skinning.interface%7Cmediawiki.toc.styles%7Cskins.vector.styles%7Cwikibase.client.init&amp;only=styles&amp;skin=vector"/>
    <script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;skin=vector"></script>
    <meta name="ResourceLoaderDynamicStyles" content=""/>
    <link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.gadget.charinsert-styles&amp;only=styles&amp;skin=vector"/>
    <link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
    <meta name="generator" content="MediaWiki 1.34.0-wmf.8"/>
    <meta name="referrer" content="origin"/>
    <meta name="referrer" content="origin-when-crossorigin"/>
    <meta name="referrer" content="origin-when-cross-origin"/>
    <meta property="og:image" content="https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/ECF_RGB.jpg/1200px-ECF_RGB.jpg"/>
    <link rel="alternate" href="android-app://org.wikipedia/http/en.m.wikipedia.org/wiki/European_Climate_Foundation"/>
    <link rel="alternate" type="application/x-wiki" title="Edit this page" href="/w/index.php?title=European_Climate_Foundation&amp;action=edit"/>
    <link rel="edit" title="Edit this page" href="/w/index.php?title=European_Climate_Foundation&amp;action=edit"/>
    <link rel="apple-touch-icon" href="/static/apple-touch/wikipedia.png"/>
    <link rel="shortcut icon" href="/static/favicon/wikipedia.ico"/>
    <link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikipedia (en)"/>
    <link rel="EditURI" type="application/rsd+xml" href="//en.wikipedia.org/w/api.php?action=rsd"/>
    <link rel="license" href="//creativecommons.org/licenses/by-sa/3.0/"/>
    <link rel="canonical" href="https://en.wikipedia.org/wiki/European_Climate_Foundation"/>
    <link rel="dns-prefetch" href="//login.wikimedia.org"/>
    <link rel="dns-prefetch" href="//meta.wikimedia.org" />
    <!--[if lt IE 9]><script src="/w/load.php?lang=qqx&amp;modules=html5shiv&amp;only=scripts&amp;skin=fallback&amp;sync=1"></script><![endif]-->
    </head>
    <body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-0 ns-subject mw-editable page-European_Climate_Foundation rootpage-European_Climate_Foundation skin-vector action-view">
    <div id="mw-page-base" class="noprint"></div>
    <div id="mw-head-base" class="noprint"></div>
    <div id="content" class="mw-body" role="main">
    	<a id="top"></a>
    	<div id="siteNotice" class="mw-body-content"><!-- CentralNotice --></div>
    	<div class="mw-indicators mw-body-content">
    </div>
    
    	<h1 id="firstHeading" class="firstHeading" lang="en">European Climate Foundation</h1>
    	
    	<div id="bodyContent" class="mw-body-content">
    		<div id="siteSub" class="noprint">From Wikipedia, the free encyclopedia</div>
    		<div id="contentSub"></div>
    		
    		
    		
    		<div id="jump-to-nav"></div>
    		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
    		<a class="mw-jump-link" href="#p-search">Jump to search</a>
    		<div id="mw-content-text" lang="en" dir="ltr" class="mw-content-ltr"><div class="mw-parser-output"><table class="box-More_citations_needed plainlinks metadata ambox ambox-content ambox-Refimprove" role="presentation"><tbody><tr><td class="mbox-image"><div style="width:52px"><a href="/wiki/File:Question_book-new.svg" class="image"><img alt="" src="//upload.wikimedia.org/wikipedia/en/thumb/9/99/Question_book-new.svg/50px-Question_book-new.svg.png" decoding="async" width="50" height="39" srcset="//upload.wikimedia.org/wikipedia/en/thumb/9/99/Question_book-new.svg/75px-Question_book-new.svg.png 1.5x, //upload.wikimedia.org/wikipedia/en/thumb/9/99/Question_book-new.svg/100px-Question_book-new.svg.png 2x" data-file-width="512" data-file-height="399" /></a></div></td><td class="mbox-text"><div class="mbox-text-span">This article <b>needs additional citations for <a href="/wiki/Wikipedia:Verifiability" title="Wikipedia:Verifiability">verification</a></b>.<span class="hide-when-compact"> Please help <a class="external text" href="//en.wikipedia.org/w/index.php?title=European_Climate_Foundation&amp;action=edit">improve this article</a> by <a href="/wiki/Help:Introduction_to_referencing_with_Wiki_Markup/1" title="Help:Introduction to referencing with Wiki Markup/1">adding citations to reliable sources</a>. Unsourced material may be challenged and removed.<br /><small><span class="plainlinks"><i>Find sources:</i>&#160;<a rel="nofollow" class="external text" href="//www.google.com/search?as_eq=wikipedia&amp;q=%22European+Climate+Foundation%22">"European Climate Foundation"</a>&#160;–&#160;<a rel="nofollow" class="external text" href="//www.google.com/search?tbm=nws&amp;q=%22European+Climate+Foundation%22+-wikipedia">news</a>&#160;<b>·</b> <a rel="nofollow" class="external text" href="//www.google.com/search?&amp;q=%22European+Climate+Foundation%22+site:news.google.com/newspapers&amp;source=newspapers">newspapers</a>&#160;<b>·</b> <a rel="nofollow" class="external text" href="//www.google.com/search?tbs=bks:1&amp;q=%22European+Climate+Foundation%22+-wikipedia">books</a>&#160;<b>·</b> <a rel="nofollow" class="external text" href="//scholar.google.com/scholar?q=%22European+Climate+Foundation%22">scholar</a>&#160;<b>·</b> <a rel="nofollow" class="external text" href="https://www.jstor.org/action/doBasicSearch?Query=%22European+Climate+Foundation%22&amp;acc=on&amp;wc=on">JSTOR</a></span></small></span>  <small class="date-container"><i>(<span class="date">May 2015</span>)</i></small><small class="hide-when-compact"><i> (<a href="/wiki/Help:Maintenance_template_removal" title="Help:Maintenance template removal">Learn how and when to remove this template message</a>)</i></small></div></td></tr></tbody></table>
    <div class="thumb tright"><div class="thumbinner" style="width:258px;"><a href="/wiki/File:ECF_RGB.jpg" class="image"><img alt="ECF RGB.jpg" src="//upload.wikimedia.org/wikipedia/commons/thumb/5/59/ECF_RGB.jpg/256px-ECF_RGB.jpg" decoding="async" width="256" height="129" class="thumbimage" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/5/59/ECF_RGB.jpg/384px-ECF_RGB.jpg 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/5/59/ECF_RGB.jpg/512px-ECF_RGB.jpg 2x" data-file-width="6146" data-file-height="3101" /></a>  <div class="thumbcaption"><div class="magnify"><a href="/wiki/File:ECF_RGB.jpg" class="internal" title="Enlarge"></a></div></div></div></div>
    <p><b>European Climate Foundation</b> of <b>ECF</b> was founded in 2008 as an international non-profit organisation whose aims are to promote <a href="/wiki/Climate_and_energy" title="Climate and energy">climate and energy</a> policies that it says would reduce <a href="/wiki/Europe" title="Europe">Europe</a>'s <a href="/wiki/Greenhouse_gas_emissions" class="mw-redirect" title="Greenhouse gas emissions">greenhouse gas emissions</a> and to help Europe play a stronger international leadership role in mitigating <a href="/wiki/Climate_change" title="Climate change">climate change</a>.<sup id="cite_ref-1" class="reference"><a href="#cite_note-1">&#91;1&#93;</a></sup> 
    </p>
    <div id="toc" class="toc"><input type="checkbox" role="button" id="toctogglecheckbox" class="toctogglecheckbox" style="display:none" /><div class="toctitle" lang="en" dir="ltr"><h2>Contents</h2><span class="toctogglespan"><label class="toctogglelabel" for="toctogglecheckbox"></label></span></div>
    <ul>
    <li class="toclevel-1 tocsection-1"><a href="#General"><span class="tocnumber">1</span> <span class="toctext">General</span></a></li>
    <li class="toclevel-1 tocsection-2"><a href="#Funding"><span class="tocnumber">2</span> <span class="toctext">Funding</span></a></li>
    <li class="toclevel-1 tocsection-3"><a href="#References"><span class="tocnumber">3</span> <span class="toctext">References</span></a></li>
    <li class="toclevel-1 tocsection-4"><a href="#External_links"><span class="tocnumber">4</span> <span class="toctext">External links</span></a></li>
    </ul>
    </div>
    
    <h2><span class="mw-headline" id="General">General</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=European_Climate_Foundation&amp;action=edit&amp;section=1" title="Edit section: General">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <p>According to the group, key elements of a <a href="/wiki/Sustainable_energy" title="Sustainable energy">sustainable energy</a> future include:
    </p>
    <ul><li>A substantial increase in <a href="/wiki/Efficient_energy_use" title="Efficient energy use">energy efficiency</a></li>
    <li>A successful transition from conventional to <a href="/wiki/Renewable_energy" title="Renewable energy">renewable energy</a></li>
    <li>Maintenance of the earth’s ecological systems and the life-supporting services they provide</li>
    <li>Equitable distribution of <a href="/wiki/Energy_services" class="mw-redirect" title="Energy services">energy services</a> to different segments of the population, both internationally and within nations.</li></ul>
    <p>The European Climate Foundation is funded by the <a href="/wiki/Nationale_Postcode_Loterij" title="Nationale Postcode Loterij">Nationale Postcode Loterij</a>, <a href="/wiki/Lisbet_Rausing" title="Lisbet Rausing">The Arcadia Fund</a>, <a href="/wiki/The_Children%27s_Investment_Fund_Foundation" title="The Children&#39;s Investment Fund Foundation">The Children's Investment Fund Foundation</a>, The <a href="/wiki/ClimateWorks_Foundation" title="ClimateWorks Foundation">ClimateWorks Foundation</a>, <a href="/wiki/John_MacBain" title="John MacBain">The McCall MacBain Foundation</a>, Oak Foundation, <a href="/wiki/Petter_Stordalen" title="Petter Stordalen">The Stordalen Foundation</a> and <a href="/wiki/The_William_and_Flora_Hewlett_Foundation" class="mw-redirect" title="The William and Flora Hewlett Foundation">The William and Flora Hewlett Foundation</a>.
    </p>
    <h2><span class="mw-headline" id="Funding">Funding</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=European_Climate_Foundation&amp;action=edit&amp;section=2" title="Edit section: Funding">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <p>The European Climate Foundation established <a href="/wiki/CarbonBrief" title="CarbonBrief">CarbonBrief</a> in the end of 2010.<sup id="cite_ref-Drum1_2-0" class="reference"><a href="#cite_note-Drum1-2">&#91;2&#93;</a></sup>
    </p>
    <h2><span class="mw-headline" id="References">References</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=European_Climate_Foundation&amp;action=edit&amp;section=3" title="Edit section: References">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <div class="mw-references-wrap"><ol class="references">
    <li id="cite_note-1"><span class="mw-cite-backlink"><b><a href="#cite_ref-1">^</a></b></span> <span class="reference-text"><a rel="nofollow" class="external text" href="https://europeanclimate.org/mission/vision/">https://europeanclimate.org/mission/vision/</a></span>
    </li>
    <li id="cite_note-Drum1-2"><span class="mw-cite-backlink"><b><a href="#cite_ref-Drum1_2-0">^</a></b></span> <span class="reference-text"><cite class="citation web"><a rel="nofollow" class="external text" href="https://www.thedrum.com/opinion/2017/06/15/how-twitter-and-carbon-brief-are-helping-climate-change-scientists-fight-donald">"How Twitter and Carbon Brief are helping climate change scientists fight Donald Trump online"</a>. <i>The Drum</i>. 2017.</cite><span title="ctx_ver=Z39.88-2004&amp;rft_val_fmt=info%3Aofi%2Ffmt%3Akev%3Amtx%3Ajournal&amp;rft.genre=unknown&amp;rft.jtitle=The+Drum&amp;rft.atitle=How+Twitter+and+Carbon+Brief+are+helping+climate+change+scientists+fight+Donald+Trump+online&amp;rft.date=2017&amp;rft_id=https%3A%2F%2Fwww.thedrum.com%2Fopinion%2F2017%2F06%2F15%2Fhow-twitter-and-carbon-brief-are-helping-climate-change-scientists-fight-donald&amp;rfr_id=info%3Asid%2Fen.wikipedia.org%3AEuropean+Climate+Foundation" class="Z3988"></span><style data-mw-deduplicate="TemplateStyles:r886058088">.mw-parser-output cite.citation{font-style:inherit}.mw-parser-output .citation q{quotes:"\"""\"""'""'"}.mw-parser-output .citation .cs1-lock-free a{background:url("//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Lock-green.svg/9px-Lock-green.svg.png")no-repeat;background-position:right .1em center}.mw-parser-output .citation .cs1-lock-limited a,.mw-parser-output .citation .cs1-lock-registration a{background:url("//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Lock-gray-alt-2.svg/9px-Lock-gray-alt-2.svg.png")no-repeat;background-position:right .1em center}.mw-parser-output .citation .cs1-lock-subscription a{background:url("//upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Lock-red-alt-2.svg/9px-Lock-red-alt-2.svg.png")no-repeat;background-position:right .1em center}.mw-parser-output .cs1-subscription,.mw-parser-output .cs1-registration{color:#555}.mw-parser-output .cs1-subscription span,.mw-parser-output .cs1-registration span{border-bottom:1px dotted;cursor:help}.mw-parser-output .cs1-ws-icon a{background:url("//upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/12px-Wikisource-logo.svg.png")no-repeat;background-position:right .1em center}.mw-parser-output code.cs1-code{color:inherit;background:inherit;border:inherit;padding:inherit}.mw-parser-output .cs1-hidden-error{display:none;font-size:100%}.mw-parser-output .cs1-visible-error{font-size:100%}.mw-parser-output .cs1-maint{display:none;color:#33aa33;margin-left:0.3em}.mw-parser-output .cs1-subscription,.mw-parser-output .cs1-registration,.mw-parser-output .cs1-format{font-size:95%}.mw-parser-output .cs1-kern-left,.mw-parser-output .cs1-kern-wl-left{padding-left:0.2em}.mw-parser-output .cs1-kern-right,.mw-parser-output .cs1-kern-wl-right{padding-right:0.2em}</style></span>
    </li>
    </ol></div>
    <h2><span class="mw-headline" id="External_links">External links</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=European_Climate_Foundation&amp;action=edit&amp;section=4" title="Edit section: External links">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <ul><li><a rel="nofollow" class="external text" href="http://www.europeanclimate.org">European Climate Foundation website</a></li></ul>
    <div role="navigation" class="navbox" aria-labelledby="Sustainability" style="padding:3px"><table class="nowraplinks hlist collapsible collapsed navbox-inner" style="border-spacing:0;background:transparent;color:inherit"><tbody><tr><th scope="col" class="navbox-title" colspan="2"><div class="plainlinks hlist navbar mini"><ul><li class="nv-view"><a href="/wiki/Template:Sustainability" title="Template:Sustainability"><abbr title="View this template" style=";;background:none transparent;border:none;-moz-box-shadow:none;-webkit-box-shadow:none;box-shadow:none; padding:0;">v</abbr></a></li><li class="nv-talk"><a href="/wiki/Template_talk:Sustainability" title="Template talk:Sustainability"><abbr title="Discuss this template" style=";;background:none transparent;border:none;-moz-box-shadow:none;-webkit-box-shadow:none;box-shadow:none; padding:0;">t</abbr></a></li><li class="nv-edit"><a class="external text" href="//en.wikipedia.org/w/index.php?title=Template:Sustainability&amp;action=edit"><abbr title="Edit this template" style=";;background:none transparent;border:none;-moz-box-shadow:none;-webkit-box-shadow:none;box-shadow:none; padding:0;">e</abbr></a></li></ul></div><div id="Sustainability" style="font-size:114%;margin:0 4em"><a href="/wiki/Sustainability" title="Sustainability">Sustainability</a></div></th></tr><tr><th scope="row" class="navbox-group" style="width:1%"><a href="/wiki/Sustainability#Principles_and_concepts" title="Sustainability">Principles</a></th><td class="navbox-list navbox-odd" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/Anthropocene" title="Anthropocene">Anthropocene</a></li>
    <li><a href="/wiki/Earth_system_governance" title="Earth system governance">Earth system governance</a></li>
    <li><a href="/wiki/Ecological_modernization" title="Ecological modernization">Ecological modernization</a></li>
    <li><a href="/wiki/Environmental_governance" title="Environmental governance">Environmental governance</a></li>
    <li><a href="/wiki/Environmentalism" title="Environmentalism">Environmentalism</a></li>
    <li><a href="/wiki/Global_catastrophic_risk" title="Global catastrophic risk">Global catastrophic risk</a></li>
    <li><a href="/wiki/Human_impact_on_the_environment" title="Human impact on the environment">Human impact on the environment</a></li>
    <li><a href="/wiki/Planetary_boundaries" title="Planetary boundaries">Planetary boundaries</a></li>
    <li><a href="/wiki/Social_sustainability" title="Social sustainability">Social sustainability</a></li>
    <li><a href="/wiki/Stewardship" title="Stewardship">Stewardship</a></li>
    <li><a href="/wiki/Sustainable_development" title="Sustainable development">Sustainable development</a></li></ul>
    </div></td></tr><tr><th scope="row" class="navbox-group" style="width:1%"><a href="/wiki/Consumption_(economics)" title="Consumption (economics)">Consumption</a></th><td class="navbox-list navbox-even" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/Anthropization" title="Anthropization">Anthropization</a></li>
    <li><a href="/wiki/Anti-consumerism" title="Anti-consumerism">Anti-consumerism</a></li>
    <li><a href="/wiki/Earth_Overshoot_Day" title="Earth Overshoot Day">Earth Overshoot Day</a></li>
    <li><a href="/wiki/Ecological_footprint" title="Ecological footprint">Ecological footprint</a></li>
    <li><a href="/wiki/Ethical_consumerism" title="Ethical consumerism">Ethical</a></li>
    <li><a href="/wiki/Over-consumption" class="mw-redirect" title="Over-consumption">Over-consumption</a></li>
    <li><a href="/wiki/Simple_living" title="Simple living">Simple living</a></li>
    <li><a href="/wiki/Sustainability_advertising" title="Sustainability advertising">Sustainability advertising</a></li>
    <li><a href="/wiki/Sustainability_brand" title="Sustainability brand">Sustainability brand</a></li>
    <li><a href="/wiki/Sustainability_marketing_myopia" title="Sustainability marketing myopia">Sustainability marketing myopia</a></li>
    <li><a href="/wiki/Sustainable_consumption" title="Sustainable consumption">Sustainable</a></li>
    <li><a href="/wiki/Sustainability_and_systemic_change_resistance" title="Sustainability and systemic change resistance">Systemic change resistance</a></li>
    <li><a href="/wiki/Tragedy_of_the_commons" title="Tragedy of the commons">Tragedy of the commons</a></li></ul>
    </div></td></tr><tr><th scope="row" class="navbox-group" style="width:1%"><a href="/wiki/Population" title="Population">Population</a></th><td class="navbox-list navbox-odd" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/Birth_control" title="Birth control">Birth control</a></li>
    <li><a href="/wiki/Family_planning" title="Family planning">Family planning</a></li>
    <li><a href="/wiki/Human_population_control" class="mw-redirect" title="Human population control">Control</a></li>
    <li><a href="/wiki/Human_overpopulation" title="Human overpopulation">Overpopulation</a></li>
    <li><a href="/wiki/Zero_population_growth" title="Zero population growth">Zero growth</a></li></ul>
    </div></td></tr><tr><th scope="row" class="navbox-group" style="width:1%">Technology</th><td class="navbox-list navbox-even" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/Appropriate_technology" title="Appropriate technology">Appropriate</a></li>
    <li><a href="/wiki/Environmental_technology" title="Environmental technology">Environmental</a></li>
    <li><a href="/wiki/Sustainable_design" title="Sustainable design">Sustainable</a></li></ul>
    </div></td></tr><tr><th scope="row" class="navbox-group" style="width:1%"><a href="/wiki/Biodiversity" title="Biodiversity">Biodiversity</a></th><td class="navbox-list navbox-odd" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/Biosecurity" title="Biosecurity">Biosecurity</a></li>
    <li><a href="/wiki/Biosphere" title="Biosphere">Biosphere</a></li>
    <li><a href="/wiki/Conservation_biology" title="Conservation biology">Conservation biology</a></li>
    <li><a href="/wiki/Deep_ecology" title="Deep ecology">Deep ecology</a></li>
    <li><a href="/wiki/Endangered_species" title="Endangered species">Endangered species</a></li>
    <li><a href="/wiki/Holocene_extinction" title="Holocene extinction">Holocene extinction</a></li>
    <li><a href="/wiki/Invasive_species" title="Invasive species">Invasive species</a></li></ul>
    </div></td></tr><tr><th scope="row" class="navbox-group" style="width:1%">Energy</th><td class="navbox-list navbox-even" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/Carbon_footprint" title="Carbon footprint">Carbon footprint</a></li>
    <li><a href="/wiki/Climate_change_mitigation" title="Climate change mitigation">Climate change mitigation</a></li>
    <li><a href="/wiki/Energy_conservation" title="Energy conservation">Conservation</a></li>
    <li><a href="/wiki/Energy_descent" title="Energy descent">Descent</a></li>
    <li><a href="/wiki/Efficient_energy_use" title="Efficient energy use">Efficiency</a></li>
    <li><a href="/wiki/Emissions_trading" title="Emissions trading">Emissions trading</a></li>
    <li><a href="/wiki/Fossil-fuel_phase-out" class="mw-redirect" title="Fossil-fuel phase-out">Fossil-fuel phase-out</a></li>
    <li><a href="/wiki/Peak_oil" title="Peak oil">Peak oil</a></li>
    <li><a href="/wiki/Energy_poverty" title="Energy poverty">Poverty</a></li>
    <li><a href="/wiki/Rebound_effect_(conservation)" title="Rebound effect (conservation)">Rebound effect</a></li>
    <li><a href="/wiki/Renewable_energy" title="Renewable energy">Renewable</a></li></ul>
    </div></td></tr><tr><th scope="row" class="navbox-group" style="width:1%">Food</th><td class="navbox-list navbox-odd" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/Forest_gardening" title="Forest gardening">Forest gardening</a></li>
    <li><a href="/wiki/Local_food" title="Local food">Local</a></li>
    <li><a href="/wiki/Permaculture" title="Permaculture">Permaculture</a></li>
    <li><a href="/wiki/Food_security" title="Food security">Security</a></li>
    <li><a href="/wiki/Sustainable_agriculture" title="Sustainable agriculture">Sustainable agriculture</a></li>
    <li><a href="/wiki/Sustainable_fishery" title="Sustainable fishery">Sustainable fishery</a></li>
    <li><a href="/wiki/Urban_horticulture" title="Urban horticulture">Urban horticulture</a></li></ul>
    </div></td></tr><tr><th scope="row" class="navbox-group" style="width:1%">Water</th><td class="navbox-list navbox-even" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/Water_conservation" title="Water conservation">Conservation</a></li>
    <li><a href="/wiki/Water_crisis" class="mw-redirect" title="Water crisis">Crisis</a></li>
    <li><a href="/wiki/Water_efficiency" title="Water efficiency">Efficiency</a></li>
    <li><a href="/wiki/Water_footprint" title="Water footprint">Footprint</a></li>
    <li><a href="/wiki/Reclaimed_water" title="Reclaimed water">Reclaimed</a></li></ul>
    </div></td></tr><tr><th scope="row" class="navbox-group" style="width:1%">Accountability</th><td class="navbox-list navbox-odd" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/Sustainability_accounting" title="Sustainability accounting">Sustainability accounting</a></li>
    <li><a href="/wiki/Sustainability_measurement" title="Sustainability measurement">Sustainability measurement</a></li>
    <li><a href="/wiki/Sustainability_metrics_and_indices" title="Sustainability metrics and indices">Sustainability metrics and indices</a></li>
    <li><a href="/wiki/Sustainability_reporting" title="Sustainability reporting">Sustainability reporting</a></li>
    <li><a href="/wiki/Sustainability_standards_and_certification" title="Sustainability standards and certification">Standards and certification</a></li>
    <li><a href="/wiki/Sustainable_yield" title="Sustainable yield">Sustainable yield</a></li></ul>
    </div></td></tr><tr><th scope="row" class="navbox-group" style="width:1%">Applications</th><td class="navbox-list navbox-even" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/Sustainable_advertising" title="Sustainable advertising">Advertising</a></li>
    <li><a href="/wiki/Sustainable_architecture" title="Sustainable architecture">Architecture</a></li>
    <li><a href="/wiki/Sustainable_art" title="Sustainable art">Art</a></li>
    <li><a href="/wiki/Sustainable_business" title="Sustainable business">Business</a></li>
    <li><a href="/wiki/Sustainable_city" title="Sustainable city">City</a></li>
    <li><a href="/wiki/North_American_collegiate_sustainability_programs" title="North American collegiate sustainability programs">College programs</a></li>
    <li><a href="/wiki/Sustainable_community" title="Sustainable community">Community</a></li>
    <li><a href="/wiki/Sustainable_design" title="Sustainable design">Design</a></li>
    <li><a href="/wiki/Ecovillage" title="Ecovillage">Ecovillage</a></li>
    <li><a href="/wiki/Education_for_Sustainable_Development" class="mw-redirect" title="Education for Sustainable Development">Education for Sustainable Development</a></li>
    <li><a href="/wiki/Sustainable_fashion" title="Sustainable fashion">Fashion</a></li>
    <li><a href="/wiki/Sustainable_gardening" title="Sustainable gardening">Gardening</a></li>
    <li><a href="/wiki/Geopark" title="Geopark">Geopark</a></li>
    <li><a href="/wiki/Green_marketing" title="Green marketing">Green marketing</a></li>
    <li><a href="/wiki/Sustainable_industries" title="Sustainable industries">Industries</a></li>
    <li><a href="/wiki/Sustainable_landscape_architecture" title="Sustainable landscape architecture">Landscape architecture</a></li>
    <li><a href="/wiki/Sustainable_living" title="Sustainable living">Living</a></li>
    <li><a href="/wiki/Low-impact_development_(UK)" title="Low-impact development (UK)">Low-impact development</a></li>
    <li><a href="/wiki/Sustainable_market" class="mw-redirect" title="Sustainable market">Sustainable market</a></li>
    <li><a href="/wiki/Sustainability_organizations" title="Sustainability organizations">Organizations</a></li>
    <li><a href="/wiki/Sustainable_packaging" title="Sustainable packaging">Packaging</a></li>
    <li><a href="/wiki/Sustainability_practices_in_organizations" class="mw-redirect" title="Sustainability practices in organizations">Practices</a></li>
    <li><a href="/wiki/Sustainable_procurement" title="Sustainable procurement">Procurement</a></li>
    <li><a href="/wiki/Sustainable_tourism" title="Sustainable tourism">Tourism</a></li>
    <li><a href="/wiki/Sustainable_transport" title="Sustainable transport">Transport</a></li>
    <li><a href="/wiki/Sustainable_urban_drainage_systems" class="mw-redirect" title="Sustainable urban drainage systems">Urban drainage systems</a></li>
    <li><a href="/wiki/Sustainable_urban_infrastructure" title="Sustainable urban infrastructure">Urban infrastructure</a></li>
    <li><a href="/wiki/New_Urbanism" title="New Urbanism">Urbanism</a></li></ul>
    </div></td></tr><tr><th scope="row" class="navbox-group" style="width:1%">Management</th><td class="navbox-list navbox-odd" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/Sustainability_and_environmental_management" title="Sustainability and environmental management">Environmental</a></li>
    <li><a href="/wiki/Fisheries_management" title="Fisheries management">Fisheries</a></li>
    <li><a href="/wiki/Sustainable_forest_management" title="Sustainable forest management">Forest</a></li>
    <li><a href="/wiki/Sustainable_materials_management" title="Sustainable materials management">Materials</a></li>
    <li><a href="/wiki/Natural_resource_management" title="Natural resource management">Natural resource</a></li>
    <li><a href="/wiki/Planetary_management" title="Planetary management">Planetary</a></li>
    <li><a href="/wiki/Waste_management" title="Waste management">Waste</a></li></ul>
    </div></td></tr><tr><th scope="row" class="navbox-group" style="width:1%">Agreements</th><td class="navbox-list navbox-even" style="text-align:left;border-left-width:2px;border-left-style:solid;width:100%;padding:0px"><div style="padding:0em 0.25em">
    <ul><li><a href="/wiki/United_Nations_Conference_on_the_Human_Environment" title="United Nations Conference on the Human Environment"><span class="wrap">UN Conference on the Human Environment (Stockholm 1972)</span></a></li>
    <li><a href="/wiki/Brundtland_Commission" title="Brundtland Commission">Brundtlandt Commission Report (1983)</a></li>
    <li><a href="/wiki/Our_Common_Future" title="Our Common Future"><i>Our Common Future</i> (1987)</a></li>
    <li><a href="/wiki/Earth_Summit" title="Earth Summit">Earth Summit (1992)</a></li>
    <li><a href="/wiki/Rio_Declaration_on_Environment_and_Development" title="Rio Declaration on Environment and Development">Rio Declaration on Environment and Development</a></li>
    <li><a href="/wiki/Agenda_21" title="Agenda 21">Agenda 21 (1992)</a></li>
    <li><a href="/wiki/Convention_on_Biological_Diversity" title="Convention on Biological Diversity">Convention on Biological Diversity (1992)</a></li>
    <li><a href="/wiki/International_Conference_on_Population_and_Development" title="International Conference on Population and Development">ICPD Programme of Action (1994)</a></li>
    <li><a href="/wiki/Earth_Charter" title="Earth Charter">Earth Charter</a></li>
    <li><a href="/wiki/Lisbon_Principles" title="Lisbon Principles">Lisbon Principles</a></li>
    <li><a href="/wiki/United_Nations_Millennium_Declaration" title="United Nations Millennium Declaration">UN Millennium Declaration (2000)</a></li>
    <li><a href="/wiki/Earth_Summit_2002" title="Earth Summit 2002">Earth Summit 2002</a> (Rio+10, Johannesburg)</li>
    <li><a href="/wiki/United_Nations_Conference_on_Sustainable_Development" title="United Nations Conference on Sustainable Development">United Nations Conference on Sustainable Development</a> (Rio+20, 2012)</li>
    <li><a href="/wiki/Sustainable_Development_Goals" title="Sustainable Development Goals">Sustainable Development Goals</a></li></ul>
    </div></td></tr><tr><td class="navbox-abovebelow" colspan="2"><div>
    <ul><li><a href="/wiki/Category:Sustainability" title="Category:Sustainability">Category</a></li>
    <li><a href="/wiki/Category:Sustainability_lists" title="Category:Sustainability lists">Lists</a></li>
    <li><a href="/wiki/Outline_of_sustainability" title="Outline of sustainability">Outline</a></li>
    <li><a href="/wiki/Portal:Sustainable_development" title="Portal:Sustainable development">Portal</a></li>
    <li><a href="/wiki/Sustainability_science" title="Sustainability science">Science</a></li>
    <li><a href="/wiki/Sustainability_studies" title="Sustainability studies">Studies</a></li>
    <li><a href="/wiki/List_of_environmental_degrees" title="List of environmental degrees">Degrees</a></li></ul>
    </div></td></tr></tbody></table></div>
    <div class="noprint metadata navbox" role="navigation" aria-label="Portals" style="font-weight:bold;padding:0.4em 2em"><ul style="margin:0.1em 0 0"><li style="display:inline"><span style="display:inline-block;white-space:nowrap"><span style="margin:0 0.5em"><a href="/wiki/File:Aegopodium_podagraria1_ies.jpg" class="image"><img alt="Aegopodium podagraria1 ies.jpg" src="//upload.wikimedia.org/wikipedia/commons/thumb/b/bf/Aegopodium_podagraria1_ies.jpg/24px-Aegopodium_podagraria1_ies.jpg" decoding="async" width="24" height="21" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/b/bf/Aegopodium_podagraria1_ies.jpg/36px-Aegopodium_podagraria1_ies.jpg 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/b/bf/Aegopodium_podagraria1_ies.jpg/48px-Aegopodium_podagraria1_ies.jpg 2x" data-file-width="800" data-file-height="700" /></a></span><a href="/wiki/Portal:Environment" title="Portal:Environment">Environment portal</a></span></li><li style="display:inline"><span style="display:inline-block;white-space:nowrap"><span style="margin:0 0.5em"><a href="/wiki/File:Sustainable_development.svg" class="image"><img alt="Sustainable development.svg" src="//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Sustainable_development.svg/24px-Sustainable_development.svg.png" decoding="async" width="24" height="15" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Sustainable_development.svg/36px-Sustainable_development.svg.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/7/70/Sustainable_development.svg/48px-Sustainable_development.svg.png 2x" data-file-width="512" data-file-height="326" /></a></span><a href="/wiki/Portal:Sustainable_development" title="Portal:Sustainable development">Sustainable development portal</a></span></li></ul></div>
    <table class="metadata plainlinks stub" role="presentation" style="background:transparent"><tbody><tr><td><a href="/wiki/File:LocationEurope.png" class="image"><img alt="Stub icon" src="//upload.wikimedia.org/wikipedia/commons/thumb/e/e9/LocationEurope.png/60px-LocationEurope.png" decoding="async" width="60" height="31" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/e/e9/LocationEurope.png/90px-LocationEurope.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/e/e9/LocationEurope.png/120px-LocationEurope.png 2x" data-file-width="2759" data-file-height="1404" /></a></td><td><i>This Europe-related article is a <a href="/wiki/Wikipedia:Stub" title="Wikipedia:Stub">stub</a>. You can help Wikipedia by <a class="external text" href="//en.wikipedia.org/w/index.php?title=European_Climate_Foundation&amp;action=edit">expanding it</a>.</i><div class="plainlinks hlist navbar mini" style="position: absolute; right: 15px; display: none;"><ul><li class="nv-view"><a href="/wiki/Template:Europe-stub" title="Template:Europe-stub"><abbr title="View this template">v</abbr></a></li><li class="nv-talk"><a href="/wiki/Template_talk:Europe-stub" title="Template talk:Europe-stub"><abbr title="Discuss this template">t</abbr></a></li><li class="nv-edit"><a class="external text" href="//en.wikipedia.org/w/index.php?title=Template:Europe-stub&amp;action=edit"><abbr title="Edit this template">e</abbr></a></li></ul></div></td></tr></tbody></table>
    <!-- 
    NewPP limit report
    Parsed by mw1261
    Cached time: 20190606122544
    Cache expiry: 2592000
    Dynamic content: false
    CPU time usage: 0.224 seconds
    Real time usage: 0.334 seconds
    Preprocessor visited node count: 300/1000000
    Preprocessor generated node count: 0/1500000
    Post‐expand include size: 40680/2097152 bytes
    Template argument size: 63/2097152 bytes
    Highest expansion depth: 6/40
    Expensive parser function count: 3/500
    Unstrip recursion depth: 1/20
    Unstrip post‐expand size: 3416/5000000 bytes
    Number of Wikibase entities loaded: 0/400
    Lua time usage: 0.115/10.000 seconds
    Lua memory usage: 3.3 MB/50 MB
    -->
    <!--
    Transclusion expansion time report (%,ms,calls,template)
    100.00%  254.466      1 -total
     41.84%  106.459      1 Template:More_citations_needed
     32.90%   83.723      1 Template:Ambox
     32.12%   81.726      1 Template:Cite_web
     13.72%   34.904      1 Template:Find_sources_mainspace
      8.56%   21.787      1 Template:Portal_bar
      8.01%   20.371      1 Template:Sustainability
      7.85%   19.973      1 Template:Europe-stub
      6.61%   16.810      1 Template:Asbox
      6.54%   16.646      1 Template:Navbox
    -->
    
    <!-- Saved in parser cache with key enwiki:pcache:idhash:30184825-0!canonical and timestamp 20190606122544 and revision id 895409635
     -->
    </div><noscript><img src="//en.wikipedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1" style="border: none; position: absolute;" /></noscript></div>
    		
    		<div class="printfooter">Retrieved from "<a dir="ltr" href="https://en.wikipedia.org/w/index.php?title=European_Climate_Foundation&amp;oldid=895409635">https://en.wikipedia.org/w/index.php?title=European_Climate_Foundation&amp;oldid=895409635</a>"</div>
    		
    		<div id="catlinks" class="catlinks" data-mw="interface"><div id="mw-normal-catlinks" class="mw-normal-catlinks"><a href="/wiki/Help:Category" title="Help:Category">Categories</a>: <ul><li><a href="/wiki/Category:Europe_stubs" title="Category:Europe stubs">Europe stubs</a></li><li><a href="/wiki/Category:Climate_change_organizations" title="Category:Climate change organizations">Climate change organizations</a></li><li><a href="/wiki/Category:Conservation_organizations" title="Category:Conservation organizations">Conservation organizations</a></li><li><a href="/wiki/Category:Climate_change_in_Europe" title="Category:Climate change in Europe">Climate change in Europe</a></li><li><a href="/wiki/Category:European_Union_and_the_environment" title="Category:European Union and the environment">European Union and the environment</a></li></ul></div><div id="mw-hidden-catlinks" class="mw-hidden-catlinks mw-hidden-cats-hidden">Hidden categories: <ul><li><a href="/wiki/Category:Articles_needing_additional_references_from_May_2015" title="Category:Articles needing additional references from May 2015">Articles needing additional references from May 2015</a></li><li><a href="/wiki/Category:All_articles_needing_additional_references" title="Category:All articles needing additional references">All articles needing additional references</a></li><li><a href="/wiki/Category:All_stub_articles" title="Category:All stub articles">All stub articles</a></li></ul></div></div>
    		
    		<div class="visualClear"></div>
    		
    	</div>
    </div>
    
    		<div id="mw-navigation">
    			<h2>Navigation menu</h2>
    			<div id="mw-head">
    									<div id="p-personal" role="navigation" aria-labelledby="p-personal-label">
    						<h3 id="p-personal-label">Personal tools</h3>
    						<ul>
    							<li id="pt-anonuserpage">Not logged in</li><li id="pt-anontalk"><a href="/wiki/Special:MyTalk" title="Discussion about edits from this IP address [n]" accesskey="n">Talk</a></li><li id="pt-anoncontribs"><a href="/wiki/Special:MyContributions" title="A list of edits made from this IP address [y]" accesskey="y">Contributions</a></li><li id="pt-createaccount"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=European+Climate+Foundation" title="You are encouraged to create an account and log in; however, it is not mandatory">Create account</a></li><li id="pt-login"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=European+Climate+Foundation" title="You&#039;re encouraged to log in; however, it&#039;s not mandatory. [o]" accesskey="o">Log in</a></li>						</ul>
    					</div>
    									<div id="left-navigation">
    										<div id="p-namespaces" role="navigation" class="vectorTabs" aria-labelledby="p-namespaces-label">
    						<h3 id="p-namespaces-label">Namespaces</h3>
    						<ul>
    							<li id="ca-nstab-main" class="selected"><span><a href="/wiki/European_Climate_Foundation" title="View the content page [c]" accesskey="c">Article</a></span></li><li id="ca-talk"><span><a href="/wiki/Talk:European_Climate_Foundation" rel="discussion" title="Discussion about the content page [t]" accesskey="t">Talk</a></span></li>						</ul>
    					</div>
    										<div id="p-variants" role="navigation" class="vectorMenu emptyPortlet" aria-labelledby="p-variants-label">
    												<input type="checkbox" class="vectorMenuCheckbox" aria-labelledby="p-variants-label" />
    						<h3 id="p-variants-label">
    							<span>Variants</span>
    						</h3>
    						<ul class="menu">
    													</ul>
    					</div>
    									</div>
    				<div id="right-navigation">
    										<div id="p-views" role="navigation" class="vectorTabs" aria-labelledby="p-views-label">
    						<h3 id="p-views-label">Views</h3>
    						<ul>
    							<li id="ca-view" class="collapsible selected"><span><a href="/wiki/European_Climate_Foundation">Read</a></span></li><li id="ca-edit" class="collapsible"><span><a href="/w/index.php?title=European_Climate_Foundation&amp;action=edit" title="Edit this page [e]" accesskey="e">Edit</a></span></li><li id="ca-history" class="collapsible"><span><a href="/w/index.php?title=European_Climate_Foundation&amp;action=history" title="Past revisions of this page [h]" accesskey="h">View history</a></span></li>						</ul>
    					</div>
    										<div id="p-cactions" role="navigation" class="vectorMenu emptyPortlet" aria-labelledby="p-cactions-label">
    						<input type="checkbox" class="vectorMenuCheckbox" aria-labelledby="p-cactions-label" />
    						<h3 id="p-cactions-label"><span>More</span></h3>
    						<ul class="menu">
    													</ul>
    					</div>
    										<div id="p-search" role="search">
    						<h3>
    							<label for="searchInput">Search</label>
    						</h3>
    						<form action="/w/index.php" id="searchform">
    							<div id="simpleSearch">
    								<input type="search" name="search" placeholder="Search Wikipedia" title="Search Wikipedia [f]" accesskey="f" id="searchInput"/><input type="hidden" value="Special:Search" name="title"/><input type="submit" name="fulltext" value="Search" title="Search Wikipedia for this text" id="mw-searchButton" class="searchButton mw-fallbackSearchButton"/><input type="submit" name="go" value="Go" title="Go to a page with this exact name if it exists" id="searchButton" class="searchButton"/>							</div>
    						</form>
    					</div>
    									</div>
    			</div>
    			<div id="mw-panel">
    				<div id="p-logo" role="banner"><a class="mw-wiki-logo" href="/wiki/Main_Page" title="Visit the main page"></a></div>
    						<div class="portal" role="navigation" id="p-navigation" aria-labelledby="p-navigation-label">
    			<h3 id="p-navigation-label">Navigation</h3>
    			<div class="body">
    								<ul>
    					<li id="n-mainpage-description"><a href="/wiki/Main_Page" title="Visit the main page [z]" accesskey="z">Main page</a></li><li id="n-contents"><a href="/wiki/Portal:Contents" title="Guides to browsing Wikipedia">Contents</a></li><li id="n-featuredcontent"><a href="/wiki/Portal:Featured_content" title="Featured content – the best of Wikipedia">Featured content</a></li><li id="n-currentevents"><a href="/wiki/Portal:Current_events" title="Find background information on current events">Current events</a></li><li id="n-randompage"><a href="/wiki/Special:Random" title="Load a random article [x]" accesskey="x">Random article</a></li><li id="n-sitesupport"><a href="https://donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&amp;utm_medium=sidebar&amp;utm_campaign=C13_en.wikipedia.org&amp;uselang=en" title="Support us">Donate to Wikipedia</a></li><li id="n-shoplink"><a href="//shop.wikimedia.org" title="Visit the Wikipedia store">Wikipedia store</a></li>				</ul>
    							</div>
    		</div>
    			<div class="portal" role="navigation" id="p-interaction" aria-labelledby="p-interaction-label">
    			<h3 id="p-interaction-label">Interaction</h3>
    			<div class="body">
    								<ul>
    					<li id="n-help"><a href="/wiki/Help:Contents" title="Guidance on how to use and edit Wikipedia">Help</a></li><li id="n-aboutsite"><a href="/wiki/Wikipedia:About" title="Find out about Wikipedia">About Wikipedia</a></li><li id="n-portal"><a href="/wiki/Wikipedia:Community_portal" title="About the project, what you can do, where to find things">Community portal</a></li><li id="n-recentchanges"><a href="/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]" accesskey="r">Recent changes</a></li><li id="n-contactpage"><a href="//en.wikipedia.org/wiki/Wikipedia:Contact_us" title="How to contact Wikipedia">Contact page</a></li>				</ul>
    							</div>
    		</div>
    			<div class="portal" role="navigation" id="p-tb" aria-labelledby="p-tb-label">
    			<h3 id="p-tb-label">Tools</h3>
    			<div class="body">
    								<ul>
    					<li id="t-whatlinkshere"><a href="/wiki/Special:WhatLinksHere/European_Climate_Foundation" title="List of all English Wikipedia pages containing links to this page [j]" accesskey="j">What links here</a></li><li id="t-recentchangeslinked"><a href="/wiki/Special:RecentChangesLinked/European_Climate_Foundation" rel="nofollow" title="Recent changes in pages linked from this page [k]" accesskey="k">Related changes</a></li><li id="t-upload"><a href="/wiki/Wikipedia:File_Upload_Wizard" title="Upload files [u]" accesskey="u">Upload file</a></li><li id="t-specialpages"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q">Special pages</a></li><li id="t-permalink"><a href="/w/index.php?title=European_Climate_Foundation&amp;oldid=895409635" title="Permanent link to this revision of the page">Permanent link</a></li><li id="t-info"><a href="/w/index.php?title=European_Climate_Foundation&amp;action=info" title="More information about this page">Page information</a></li><li id="t-wikibase"><a href="https://www.wikidata.org/wiki/Special:EntityPage/Q5412382" title="Link to connected data repository item [g]" accesskey="g">Wikidata item</a></li><li id="t-cite"><a href="/w/index.php?title=Special:CiteThisPage&amp;page=European_Climate_Foundation&amp;id=895409635" title="Information on how to cite this page">Cite this page</a></li>				</ul>
    							</div>
    		</div>
    			<div class="portal" role="navigation" id="p-wikibase-otherprojects" aria-labelledby="p-wikibase-otherprojects-label">
    			<h3 id="p-wikibase-otherprojects-label">In other projects</h3>
    			<div class="body">
    								<ul>
    					<li class="wb-otherproject-link wb-otherproject-commons"><a href="https://commons.wikimedia.org/wiki/Category:European_Climate_Foundation" hreflang="en">Wikimedia Commons</a></li>				</ul>
    							</div>
    		</div>
    			<div class="portal" role="navigation" id="p-coll-print_export" aria-labelledby="p-coll-print_export-label">
    			<h3 id="p-coll-print_export-label">Print/export</h3>
    			<div class="body">
    								<ul>
    					<li id="coll-create_a_book"><a href="/w/index.php?title=Special:Book&amp;bookcmd=book_creator&amp;referer=European+Climate+Foundation">Create a book</a></li><li id="coll-download-as-rl"><a href="/w/index.php?title=Special:ElectronPdf&amp;page=European+Climate+Foundation&amp;action=show-download-screen">Download as PDF</a></li><li id="t-print"><a href="/w/index.php?title=European_Climate_Foundation&amp;printable=yes" title="Printable version of this page [p]" accesskey="p">Printable version</a></li>				</ul>
    							</div>
    		</div>
    			<div class="portal" role="navigation" id="p-lang" aria-labelledby="p-lang-label">
    			<h3 id="p-lang-label">Languages</h3>
    			<div class="body">
    								<ul>
    					<li class="interlanguage-link interwiki-de"><a href="https://de.wikipedia.org/wiki/European_Climate_Foundation" title="European Climate Foundation – German" lang="de" hreflang="de" class="interlanguage-link-target">Deutsch</a></li><li class="interlanguage-link interwiki-es"><a href="https://es.wikipedia.org/wiki/Fundaci%C3%B3n_Europea_para_el_Clima" title="Fundación Europea para el Clima – Spanish" lang="es" hreflang="es" class="interlanguage-link-target">Español</a></li>				</ul>
    				<div class="after-portlet after-portlet-lang"><span class="wb-langlinks-edit wb-langlinks-link"><a href="https://www.wikidata.org/wiki/Special:EntityPage/Q5412382#sitelinks-wikipedia" title="Edit interlanguage links" class="wbc-editpage">Edit links</a></span></div>			</div>
    		</div>
    				</div>
    		</div>
    				<div id="footer" role="contentinfo">
    						<ul id="footer-info">
    								<li id="footer-info-lastmod"> This page was last edited on 4 May 2019, at 02:02<span class="anonymous-show">&#160;(UTC)</span>.</li>
    								<li id="footer-info-copyright">Text is available under the <a rel="license" href="//en.wikipedia.org/wiki/Wikipedia:Text_of_Creative_Commons_Attribution-ShareAlike_3.0_Unported_License">Creative Commons Attribution-ShareAlike License</a><a rel="license" href="//creativecommons.org/licenses/by-sa/3.0/" style="display:none;"></a>;
    additional terms may apply.  By using this site, you agree to the <a href="//foundation.wikimedia.org/wiki/Terms_of_Use">Terms of Use</a> and <a href="//foundation.wikimedia.org/wiki/Privacy_policy">Privacy Policy</a>. Wikipedia® is a registered trademark of the <a href="//www.wikimediafoundation.org/">Wikimedia Foundation, Inc.</a>, a non-profit organization.</li>
    							</ul>
    						<ul id="footer-places">
    								<li id="footer-places-privacy"><a href="https://foundation.wikimedia.org/wiki/Privacy_policy" class="extiw" title="wmf:Privacy policy">Privacy policy</a></li>
    								<li id="footer-places-about"><a href="/wiki/Wikipedia:About" title="Wikipedia:About">About Wikipedia</a></li>
    								<li id="footer-places-disclaimer"><a href="/wiki/Wikipedia:General_disclaimer" title="Wikipedia:General disclaimer">Disclaimers</a></li>
    								<li id="footer-places-contact"><a href="//en.wikipedia.org/wiki/Wikipedia:Contact_us">Contact Wikipedia</a></li>
    								<li id="footer-places-developers"><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute">Developers</a></li>
    								<li id="footer-places-cookiestatement"><a href="https://foundation.wikimedia.org/wiki/Cookie_statement">Cookie statement</a></li>
    								<li id="footer-places-mobileview"><a href="//en.m.wikipedia.org/w/index.php?title=European_Climate_Foundation&amp;mobileaction=toggle_view_mobile" class="noprint stopMobileRedirectToggle">Mobile view</a></li>
    							</ul>
    										<ul id="footer-icons" class="noprint">
    										<li id="footer-copyrightico">
    						<a href="https://wikimediafoundation.org/"><img src="/static/images/wikimedia-button.png" srcset="/static/images/wikimedia-button-1.5x.png 1.5x, /static/images/wikimedia-button-2x.png 2x" width="88" height="31" alt="Wikimedia Foundation"/></a>					</li>
    										<li id="footer-poweredbyico">
    						<a href="https://www.mediawiki.org/"><img src="/static/images/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/static/images/poweredby_mediawiki_132x47.png 1.5x, /static/images/poweredby_mediawiki_176x62.png 2x" width="88" height="31"/></a>					</li>
    									</ul>
    						<div style="clear: both;"></div>
    		</div>
    		
    
    <script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgPageParseReport":{"limitreport":{"cputime":"0.224","walltime":"0.334","ppvisitednodes":{"value":300,"limit":1000000},"ppgeneratednodes":{"value":0,"limit":1500000},"postexpandincludesize":{"value":40680,"limit":2097152},"templateargumentsize":{"value":63,"limit":2097152},"expansiondepth":{"value":6,"limit":40},"expensivefunctioncount":{"value":3,"limit":500},"unstrip-depth":{"value":1,"limit":20},"unstrip-size":{"value":3416,"limit":5000000},"entityaccesscount":{"value":0,"limit":400},"timingprofile":["100.00%  254.466      1 -total"," 41.84%  106.459      1 Template:More_citations_needed"," 32.90%   83.723      1 Template:Ambox"," 32.12%   81.726      1 Template:Cite_web"," 13.72%   34.904      1 Template:Find_sources_mainspace","  8.56%   21.787      1 Template:Portal_bar","  8.01%   20.371      1 Template:Sustainability","  7.85%   19.973      1 Template:Europe-stub","  6.61%   16.810      1 Template:Asbox","  6.54%   16.646      1 Template:Navbox"]},"scribunto":{"limitreport-timeusage":{"value":"0.115","limit":"10.000"},"limitreport-memusage":{"value":3460686,"limit":52428800}},"cachereport":{"origin":"mw1261","timestamp":"20190606122544","ttl":2592000,"transientcontent":false}}});});</script>
    <script type="application/ld+json">{"@context":"https:\/\/schema.org","@type":"Article","name":"European Climate Foundation","url":"https:\/\/en.wikipedia.org\/wiki\/European_Climate_Foundation","sameAs":"http:\/\/www.wikidata.org\/entity\/Q5412382","mainEntity":"http:\/\/www.wikidata.org\/entity\/Q5412382","author":{"@type":"Organization","name":"Contributors to Wikimedia projects"},"publisher":{"@type":"Organization","name":"Wikimedia Foundation, Inc.","logo":{"@type":"ImageObject","url":"https:\/\/www.wikimedia.org\/static\/images\/wmf-hor-googpub.png"}},"datePublished":"2010-12-25T11:13:15Z","dateModified":"2019-05-04T02:02:15Z","image":"https:\/\/upload.wikimedia.org\/wikipedia\/commons\/5\/59\/ECF_RGB.jpg"}</script>
    <script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgBackendResponseTime":121,"wgHostname":"mw1271"});});</script>
    </body>
    </html>
    


## 4. Extracting the Album and Band Titles from the Page  


```python
# finidng the title xml tages and remove them

starttitle = page.find('<title>')
endtitle = page.find('</title>')
title = page[starttitle +7   : endtitle]
print(title)
```

    European Climate Foundation - Wikipedia



```python
# remove the -Wikipedia from the title

band_title = title.replace(' - Wikipedia', '')
print(band_title)
```

    European Climate Foundation


Steps 3 and 4 are repeated to create the album title. The code will be as below


```python
raw_random_wikipedia_page = requests.get(wikipedia_link)
page = raw_random_wikipedia_page.text
print(page)



```

    <!DOCTYPE html>
    <html class="client-nojs" lang="en" dir="ltr">
    <head>
    <meta charset="UTF-8"/>
    <title>Matthys du Toit - Wikipedia</title>
    <script>document.documentElement.className=document.documentElement.className.replace(/(^|\s)client-nojs(\s|$)/,"$1client-js$2");RLCONF={"wgCanonicalNamespace":"","wgCanonicalSpecialPageName":!1,"wgNamespaceNumber":0,"wgPageName":"Matthys_du_Toit","wgTitle":"Matthys du Toit","wgCurRevisionId":895176675,"wgRevisionId":895176675,"wgArticleId":60590291,"wgIsArticle":!0,"wgIsRedirect":!1,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":["1874 births","1959 deaths"],"wgBreakFrames":!1,"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgMonthNamesShort":["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"wgRelevantPageName":"Matthys_du_Toit","wgRelevantArticleId":60590291,"wgRequestId":
    "XRAjnQpAMEoAABs-p4oAAAAU","wgCSPNonce":!1,"wgIsProbablyEditable":!0,"wgRelevantPageIsProbablyEditable":!0,"wgRestrictionEdit":[],"wgRestrictionMove":[],"wgMediaViewerOnClick":!0,"wgMediaViewerEnabledByDefault":!0,"wgPopupsReferencePreviews":!1,"wgPopupsConflictsWithNavPopupGadget":!1,"wgVisualEditor":{"pageLanguageCode":"en","pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgMFDisplayWikibaseDescriptions":{"search":!0,"nearby":!0,"watchlist":!0,"tagline":!1},"wgWMESchemaEditAttemptStepOversample":!1,"wgPoweredByHHVM":!0,"wgULSCurrentAutonym":"English","wgNoticeProject":"wikipedia","wgCentralNoticeCategoriesUsingLegacy":["Fundraising","fundraising"],"wgWikibaseItemId":"Q31736577","wgCentralAuthMobileDomain":!1,"wgEditSubmitButtonLabelPublish":!0};RLSTATE={"ext.gadget.charinsert-styles":"ready","ext.globalCssJs.user.styles":"ready","ext.globalCssJs.site.styles":"ready","site.styles":"ready","noscript":"ready","user.styles":"ready",
    "ext.globalCssJs.user":"ready","ext.globalCssJs.site":"ready","user":"ready","user.options":"ready","user.tokens":"loading","ext.cite.styles":"ready","mediawiki.legacy.shared":"ready","mediawiki.legacy.commonPrint":"ready","mediawiki.toc.styles":"ready","wikibase.client.init":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready","ext.uls.interlanguage":"ready","ext.wikimediaBadges":"ready","ext.3d.styles":"ready","mediawiki.skinning.interface":"ready","skins.vector.styles":"ready"};RLPAGEMODULES=["ext.cite.ux-enhancements","site","mediawiki.page.startup","mediawiki.page.ready","mediawiki.toc","mediawiki.searchSuggest","ext.gadget.teahouse","ext.gadget.ReferenceTooltips","ext.gadget.watchlist-notice","ext.gadget.DRN-wizard","ext.gadget.charinsert","ext.gadget.refToolbar","ext.gadget.extra-toolbar-buttons","ext.gadget.switcher","ext.centralauth.centralautologin","ext.popups","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader","ext.eventLogging",
    "ext.wikimediaEvents","ext.navigationTiming","ext.uls.compactlinks","ext.uls.interface","ext.quicksurveys.init","ext.centralNotice.geoIP","ext.centralNotice.startUp","skins.vector.js"];</script>
    <script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.tokens@0tffind",function($,jQuery,require,module){/*@nomin*/mw.user.tokens.set({"editToken":"+\\","patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});
    });});</script>
    <link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.3d.styles%7Cext.cite.styles%7Cext.uls.interlanguage%7Cext.visualEditor.desktopArticleTarget.noscript%7Cext.wikimediaBadges%7Cmediawiki.legacy.commonPrint%2Cshared%7Cmediawiki.skinning.interface%7Cmediawiki.toc.styles%7Cskins.vector.styles%7Cwikibase.client.init&amp;only=styles&amp;skin=vector"/>
    <script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;skin=vector"></script>
    <meta name="ResourceLoaderDynamicStyles" content=""/>
    <link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.gadget.charinsert-styles&amp;only=styles&amp;skin=vector"/>
    <link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
    <meta name="generator" content="MediaWiki 1.34.0-wmf.8"/>
    <meta name="referrer" content="origin"/>
    <meta name="referrer" content="origin-when-crossorigin"/>
    <meta name="referrer" content="origin-when-cross-origin"/>
    <meta name="robots" content="noindex,nofollow"/>
    <link rel="alternate" href="android-app://org.wikipedia/http/en.m.wikipedia.org/wiki/Matthys_du_Toit"/>
    <link rel="alternate" type="application/x-wiki" title="Edit this page" href="/w/index.php?title=Matthys_du_Toit&amp;action=edit"/>
    <link rel="edit" title="Edit this page" href="/w/index.php?title=Matthys_du_Toit&amp;action=edit"/>
    <link rel="apple-touch-icon" href="/static/apple-touch/wikipedia.png"/>
    <link rel="shortcut icon" href="/static/favicon/wikipedia.ico"/>
    <link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikipedia (en)"/>
    <link rel="EditURI" type="application/rsd+xml" href="//en.wikipedia.org/w/api.php?action=rsd"/>
    <link rel="license" href="//creativecommons.org/licenses/by-sa/3.0/"/>
    <link rel="canonical" href="https://en.wikipedia.org/wiki/Matthys_du_Toit"/>
    <link rel="dns-prefetch" href="//login.wikimedia.org"/>
    <link rel="dns-prefetch" href="//meta.wikimedia.org" />
    <!--[if lt IE 9]><script src="/w/load.php?lang=qqx&amp;modules=html5shiv&amp;only=scripts&amp;skin=fallback&amp;sync=1"></script><![endif]-->
    </head>
    <body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-0 ns-subject mw-editable page-Matthys_du_Toit rootpage-Matthys_du_Toit skin-vector action-view">
    <div id="mw-page-base" class="noprint"></div>
    <div id="mw-head-base" class="noprint"></div>
    <div id="content" class="mw-body" role="main">
    	<a id="top"></a>
    	<div id="siteNotice" class="mw-body-content"><!-- CentralNotice --></div>
    	<div class="mw-indicators mw-body-content">
    </div>
    
    	<h1 id="firstHeading" class="firstHeading" lang="en">Matthys du Toit</h1>
    	
    	<div id="bodyContent" class="mw-body-content">
    		<div id="siteSub" class="noprint">From Wikipedia, the free encyclopedia</div>
    		<div id="contentSub"></div>
    		
    		
    		
    		<div id="jump-to-nav"></div>
    		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
    		<a class="mw-jump-link" href="#p-search">Jump to search</a>
    		<div id="mw-content-text" lang="en" dir="ltr" class="mw-content-ltr"><div class="mw-parser-output"><p>The Rev. <b>Matthys Michielse du Toit</b> (<a href="/wiki/Montagu,_Western_Cape" title="Montagu, Western Cape">Montagu</a>, <a href="/wiki/Cape_Colony" title="Cape Colony">Cape Colony</a>, December 3, 1874 - <a href="/wiki/Cape_Town" title="Cape Town">Cape Town</a>, August 18, 1959) was from 1905 until he accepted his emeritus in 1941 the pastor in six congregations of the <a href="/wiki/Dutch_Reformed_Church_in_South_Africa_(NGK)" title="Dutch Reformed Church in South Africa (NGK)">Dutch Reformed Church in South Africa (NGK)</a>, including one in <a href="/wiki/South_West_Africa" title="South West Africa">South West Africa</a>, two in the <a href="/wiki/Orange_Free_State" title="Orange Free State">Orange Free State</a>, and three in <a href="/wiki/Cape_Province" title="Cape Province">Cape Province</a>: <a href="/w/index.php?title=Barrydale_Reformed_Church_(NGK)&amp;action=edit&amp;redlink=1" class="new" title="Barrydale Reformed Church (NGK) (page does not exist)">Barrydale</a> (1905-1912), <a href="/w/index.php?title=Reddersburg_Reformed_Church_(NGK)&amp;action=edit&amp;redlink=1" class="new" title="Reddersburg Reformed Church (NGK) (page does not exist)">Reddersburg</a> (1912-1920), Excelsior (1920-1921), <a href="/wiki/Otjiwarongo_Reformed_Church_(NGK)" title="Otjiwarongo Reformed Church (NGK)">Moria</a> (now Otjiwarongo, 1921-1922), <a href="/w/index.php?title=Hopetown_Reformed_Church_(NGK)&amp;action=edit&amp;redlink=1" class="new" title="Hopetown Reformed Church (NGK) (page does not exist)">Hopetown</a> (1922-1925), and finally <a href="/wiki/Joubertina" title="Joubertina">Joubertina</a> (1925-1941). According to his own grateful testimony, "the Lord's blessing must have shadowed the work for so many Souls to be brought to the light."<sup id="cite_ref-1" class="reference"><a href="#cite_note-1">&#91;1&#93;</a></sup>
    </p><p>Especially in the last of these congregations, the mission progressed greatly under his leadership. He was long a loyal and avid member of the NGK's General Mission Commission. After accepting his emeritus, he spent a great deal of time working in various congregations, including hospital work.<sup id="cite_ref-2" class="reference"><a href="#cite_note-2">&#91;2&#93;</a></sup> At the time of his death at 85, he was the only survivor of the 17 proponents with whom he was ordained in 1904.
    </p>
    <div id="toc" class="toc"><input type="checkbox" role="button" id="toctogglecheckbox" class="toctogglecheckbox" style="display:none" /><div class="toctitle" lang="en" dir="ltr"><h2>Contents</h2><span class="toctogglespan"><label class="toctogglelabel" for="toctogglecheckbox"></label></span></div>
    <ul>
    <li class="toclevel-1 tocsection-1"><a href="#Childhood_and_education"><span class="tocnumber">1</span> <span class="toctext">Childhood and education</span></a></li>
    <li class="toclevel-1 tocsection-2"><a href="#Family_life"><span class="tocnumber">2</span> <span class="toctext">Family life</span></a></li>
    <li class="toclevel-1 tocsection-3"><a href="#Barrydale"><span class="tocnumber">3</span> <span class="toctext">Barrydale</span></a></li>
    <li class="toclevel-1 tocsection-4"><a href="#Moria"><span class="tocnumber">4</span> <span class="toctext">Moria</span></a></li>
    <li class="toclevel-1 tocsection-5"><a href="#Hopetown"><span class="tocnumber">5</span> <span class="toctext">Hopetown</span></a></li>
    <li class="toclevel-1 tocsection-6"><a href="#Joubertina"><span class="tocnumber">6</span> <span class="toctext">Joubertina</span></a>
    <ul>
    <li class="toclevel-2 tocsection-7"><a href="#General_matters"><span class="tocnumber">6.1</span> <span class="toctext">General matters</span></a></li>
    <li class="toclevel-2 tocsection-8"><a href="#Enlargement_of_the_church_building"><span class="tocnumber">6.2</span> <span class="toctext">Enlargement of the church building</span></a></li>
    <li class="toclevel-2 tocsection-9"><a href="#Church_organs"><span class="tocnumber">6.3</span> <span class="toctext">Church organs</span></a></li>
    <li class="toclevel-2 tocsection-10"><a href="#Communion_bowls"><span class="tocnumber">6.4</span> <span class="toctext">Communion bowls</span></a></li>
    <li class="toclevel-2 tocsection-11"><a href="#Death_of_the_church_mother"><span class="tocnumber">6.5</span> <span class="toctext">Death of the church mother</span></a></li>
    </ul>
    </li>
    <li class="toclevel-1 tocsection-12"><a href="#The_Rev._Du_Toit_accepts_his_emeritus"><span class="tocnumber">7</span> <span class="toctext">The Rev. Du Toit accepts his emeritus</span></a></li>
    <li class="toclevel-1 tocsection-13"><a href="#Sources"><span class="tocnumber">8</span> <span class="toctext">Sources</span></a></li>
    <li class="toclevel-1 tocsection-14"><a href="#References"><span class="tocnumber">9</span> <span class="toctext">References</span></a></li>
    </ul>
    </div>
    
    <h2><span class="mw-headline" id="Childhood_and_education">Childhood and education</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=1" title="Edit section: Childhood and education">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <p>Matthys Michielse du Toit was born the oldest son of his parents in Montagu, where he worked in his father's general store after finishing school. He received his calling in 1891 during a major spiritual revival in Montagu, spurring him to begin a long spiritual education, first in Montagu and later in <a href="/wiki/Stellenbosch" title="Stellenbosch">Stellenbosch</a>, which led him and 16 other candidates to the ministry in December 1904.
    </p>
    <h2><span class="mw-headline" id="Family_life">Family life</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=2" title="Edit section: Family life">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <p>On March 13, 1906, the young pastor married Ms. Anna Johanna Le Roux (born September 4, 1879) in <a href="/wiki/Paarl" title="Paarl">Paarl</a>. After a happy marriage of 33 years, she died at their home in Joubertina on Sunday, December 17, 1939. They had four sons who all graduated from <a href="/wiki/Stellenbosch_University" title="Stellenbosch University">Stellenbosch University</a>. After around 16 months alone in the Joubertina parsonage, the Rev. du Toit married once more to E.M. de Wet (<i>née</i> Lombard) in <a href="/wiki/Queenstown,_Eastern_Cape" title="Queenstown, Eastern Cape">Queenstown</a>. Several weeks later, he accepted his emeritus, and after many more years of volunteer work, met his eternal rest in <a href="/wiki/Rondebosch" title="Rondebosch">Rondebosch</a>.
    </p>
    <h2><span class="mw-headline" id="Barrydale">Barrydale</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=3" title="Edit section: Barrydale">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <p>The Rev. Du Toit arrived in Barrydale in 1905. In those days, a minister was expected to hold three services every Sunday. He found this taxing for his throat and the church council granted him just two of them on a doctor's advice. During his time there, a new church was built and expanded. On December 12, 1905, a special service was held there by the former pastor, G.P. van der Merwe, to usher out the old church which had served the congregation for 28 years. Unfortunately, little is known of the words the Rev. Van der Merwe spoke here, since A.A.J. van Niekerk, writer of the congregation's centennial commemorative book, couldn't find any material on it and even the oldest members of the congregation (by 1980) were too young at the time to remember anything about it. Even the few over ninety only remembered the identity of the speaker.<sup id="cite_ref-3" class="reference"><a href="#cite_note-3">&#91;3&#93;</a></sup>
    </p><p>In <i>Ons Kerk Album</i>, he is said to have worked tirelessly for the mission and to have "nurtured much real love for the cause of the Great King" among this congregation.<sup id="cite_ref-4" class="reference"><a href="#cite_note-4">&#91;4&#93;</a></sup>
    </p>
    <h2><span class="mw-headline" id="Moria">Moria</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=4" title="Edit section: Moria">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <p>At the church council meeting on April 4, 1921, of what was at the time Moria, now <a href="/wiki/Otjiwarongo" title="Otjiwarongo">Otjiwarongo</a>, the council pledged £100 to recruit a more competent pastor for the congregation over the following year. The ring passed to the Rev. M.M. du Toit, earlier of Reddersburg and Excelsior, and at the council meeting on August 6, 1921, in <a href="/wiki/Omaruru,_Namibia" title="Omaruru, Namibia">Omaruru</a>, he was accepted for the post. The Rev. Du Toit set out at once to visit the different districts in the congregation, particularly those where the railway workers who made up a large proportion of the congregation lived. Articles about his work in the <i><a href="/w/index.php?title=Kerkbode&amp;action=edit&amp;redlink=1" class="new" title="Kerkbode (page does not exist)">Kerkbode</a></i> (November 10, 1921 - November 22, 1922) give an interesting description of the times. He traveled widely, as much as 11,000 miles in one year. Most places were now accessible by rail, but he also had to use many other vehicles: "passenger train, freight train, automobile, trolley, horse-cart, mule-cart, donkey-cart, and oxcart. He even tried riding a camel."<sup id="cite_ref-5" class="reference"><a href="#cite_note-5">&#91;5&#93;</a></sup>
    </p><p>The Rev. Du Toit apparently succeeded in getting the cooperation of various local officials. Of <a href="/w/index.php?title=Gysbert_Reitz_Hofmeyr&amp;action=edit&amp;redlink=1" class="new" title="Gysbert Reitz Hofmeyr (page does not exist)">Gys Hofmeyr</a>, administrator at the time, he said: "He is not only a faithful supporter and lover of the church, but someone who confesses his love of the Lord out loud." In the <i><a href="/w/index.php?title=Kerkbode&amp;action=edit&amp;redlink=1" class="new" title="Kerkbode (page does not exist)">Kerkbode</a></i> of December 27, 1922, he published a primer to better educate the growing membership, who now numbered around 6,500 in South West Africa. W. Badenhorst and W. Hauptfleisch, stationmaster and postmaster of <a href="/wiki/Karibib" title="Karibib">Karibib</a> respectively, were "stalwarts"; and J. Hamilton, earlier an Irish Catholic, found his Sunday school in <a href="/wiki/Swakopmund" title="Swakopmund">Swakopmund</a> a great blessing. From his informative report for the Britstown Ring (1922), the Rev. Du Toit showcased his work with the Moria congregation: he had held 191 services, including 167 in Moria and 24 in <a href="/wiki/Mariental,_Namibia" title="Mariental, Namibia">Gibeon</a> (later capital of the <a href="/wiki/Mariental_Reformed_Church_(NGK)" title="Mariental Reformed Church (NGK)">Mariental Reformed Church (NGK)</a>); 21 young members were confirmed and 41 children baptized.
    </p>
    <h2><span class="mw-headline" id="Hopetown">Hopetown</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=5" title="Edit section: Hopetown">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <p>The Rev. J. de Villiers, a missionary, was there to welcome Rev. Du Toit on his investitutre as pastor of the <a href="/w/index.php?title=Hopetown_Reformed_Church_(NGK)&amp;action=edit&amp;redlink=1" class="new" title="Hopetown Reformed Church (NGK) (page does not exist)">Hopetown Reformed Church (NGK)</a> in 1922. The Rev. Du Toit worked for three years at the grueling task of not only serving the congregation itself but also traveling "in withering heat, over immense distances" to the three diamond mines within the congregation's remit. The labors took a toll on his health, as he is quoted in memoirs excerpted for the congregation's 75th anniversary commemorative book. He recalled with gratitude that his debt of £3,200 was cancelled. He remembered in particular the Pentecost revivals held by the congregation at Pentecost and the congregation's healthy relationship with the mission church.<sup id="cite_ref-6" class="reference"><a href="#cite_note-6">&#91;6&#93;</a></sup>
    </p><p>In 1923, the diggings at Brakfontein Farm were proclaimed public by W. Higgs (magistrate of <a href="/wiki/Hopetown" title="Hopetown">Hopetown</a>). A diamond rush was on, and prospector shacks sprung up like toadstools overnight. In the years that the Rev. Du Toit was pastor, the church sold its flock of sheep to supplement collections and thus pay the church's debt. A grateful congregation's church council was thereby able to buy the pastor a car to drive around the mining towns. In 1925, the church council once more provided a car to the Rev. G. Oosthuizen.
    </p><p>The church's inside was renovated then. No more would the congregation need to sit far away from the pulpit to see the pastor, since the pews were moved into a sloping floor so that one could overlook the other. From 1917 onward, the women of the congregation managed the cemetery.
    </p>
    <h2><span class="mw-headline" id="Joubertina">Joubertina</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=6" title="Edit section: Joubertina">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <p>After the resignation of the Rev. Van Rensburg of the Joubertina Reformed Church (NGK) in the <a href="/wiki/Langkloof" title="Langkloof">Langkloof</a>, the Revs. P.J. Van der Merwe (Murray, De Doorns), W.N. van der Merwe (<a href="/w/index.php?title=Wellington_Reformed_Church_(NGK)&amp;action=edit&amp;redlink=1" class="new" title="Wellington Reformed Church (NGK) (page does not exist)">Wellington</a>), and Du Toit were considered. Du Toit was officially inaugurated on Friday, September 25, 1925, and he, his wife, and their sons were ushered from <a href="/wiki/Twee_Riviere" title="Twee Riviere">Twee Riviere</a> in a procession of 18 automobiles, 38 carriages, and 68 cavalry to their welcome in Joubertina. His confirmation was held that Saturday night by the Rev. C.H. Stulting (<a href="/w/index.php?title=Humansdorp_Reformed_Church_(NGK)&amp;action=edit&amp;redlink=1" class="new" title="Humansdorp Reformed Church (NGK) (page does not exist)">Humansdorp</a>). His first communion followed on Sunday morning, and he sermonized in the afternoon on <a href="/wiki/2_Corinthians" class="mw-redirect" title="2 Corinthians">2 Corinthians</a> 12: "I'm looking for you. (i) What we seek, (ii) The road on which we search for it, (iii) How you can help us in this search."
    </p>
    <h3><span class="mw-headline" id="General_matters">General matters</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=7" title="Edit section: General matters">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
    <p>At the first Pentecost service the Rev. Du Toit celebrated with his new congregation, he was blessed by closing prayers from 82 worshipers, including 48 of the youth and children. Each communion weekend, he held five services. Saturday afternoon was the preparatory service, Saturday night was another service after which followed the church council meeting. Early Sunday morning was the children's service in the church followed by the communion service. Sunday afternoon followed another service at which baptisms were held, and Sunday night was the reflection service.<sup id="cite_ref-7" class="reference"><a href="#cite_note-7">&#91;7&#93;</a></sup>
    </p><p>In 1918, the church council began several years of negotiations to acquire 800 acres of land in the <a href="/wiki/Diepkloof_Rock_Shelter" title="Diepkloof Rock Shelter">Diepkloof Rock Shelter</a> hills for £320. The Rev. Du Toit explored the idea of planting trees on the hills and even setting up a lumber plantation.
    </p><p>The community of the Langkloof suffered a great loss with the sudden death of Mr. Giel Bokkie Olivier on April 28, 1928. He was for years a deacon, auctioneer at the thanksgiving parties, and from the foundation of the congregation until 1922, a collections manager "almost pro bono." In the religious, educational, and social spheres, he was almost indispensable to Joubertina. From the first years of the congregation, Mrs. Olivier, his wife, served as secretary of the church, until she too died on September 24, 1930, leaving the church £350 in her will.
    </p><p>With the resignation of Mr. Olivier as collections officer, a Mr. McLachlan replaced him. In 1923, a John van der Spuy took the job for a few months but then left, at which point McLachlan returned to the post until October 7, 1925, when J.G. Deyzel was formally elected to the role, which he would fill for at least a quarter-century.
    </p>
    <h3><span class="mw-headline" id="Enlargement_of_the_church_building">Enlargement of the church building</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=8" title="Edit section: Enlargement of the church building">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
    <p>Since the need for seating was only growing more pressing, plans were made starting in 1928 to build the two galleries originally planned for the church. At the same time, the clock tower had to be furnished. The clock was built by A. Fischer &amp; Kie, and it was paid for by Sunday school contributions. The galleries had to be put on hold for financial reasons, but since the fund had grown to £3,000 by 1934, the Rev. Du Toit was free to return to the project, contracting the architect <a href="/w/index.php?title=Wynand_Louw_(architect)&amp;action=edit&amp;redlink=1" class="new" title="Wynand Louw (architect) (page does not exist)">W.H. Louw</a> of <a href="/wiki/Paarl" title="Paarl">Paarl</a> and the Oberholster construction firm in 1936. Once completed, these additions added 200 pews to the church.
    </p>
    <h3><span class="mw-headline" id="Church_organs">Church organs</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=9" title="Edit section: Church organs">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
    <p>The first organ in record at the church, purchased in 1917 for £23, replaced a <a href="/wiki/Harmonium" class="mw-redirect" title="Harmonium">harmonium</a> Mrs. Augusta Cronje (later Mrs. M.J. Kritzinger) had presented to the church in December 1913. A larger organ was bought in 1930. Mrs. McLachlan, Mrs. Fourie, Mrs. J.L. du Preez, and others led the congregation's hymns accompanied by this instrument until better financial days arrived; in August 1935, a pipe organ was finally purchased for around £1,000, to use for the new galleries if possible. The first official organist was Mrs. M. Delport. To move the organ into place behind the pulpit, the building had to be altered, knocking out the upper hall. These changes, together with new carpeting for the church, cost around £34, but the amount was already covered, and therefore, no further collection drives were needed. The old gas plant's explosion led to the installation of a Westinghouse electric generator in 1931 to supply the church with light.
    </p>
    <h3><span class="mw-headline" id="Communion_bowls">Communion bowls</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=10" title="Edit section: Communion bowls">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
    <p>An uncontroversial change in Joubertina was the commissioning of communion bowls. In November 1929, the church council noted a donation of £100 for the purpose by the widow of M.J. Olivier in commemoration of his work as collector, and they immediately decided to use it to buy a set. Two years later, the old communion vessels were donated to the Malingunde mission in <a href="/wiki/Nyasaland" title="Nyasaland">Nyasaland</a>.
    </p>
    <h3><span class="mw-headline" id="Death_of_the_church_mother">Death of the church mother</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=11" title="Edit section: Death of the church mother">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
    <p>It was a tragic day not just for her husband and children but for the congregation and the Kingdom of God as well when Mrs. Du Toit died in the vicarage after a severe illness, which had left her bedridden for eight months and an inspiration to one and all. According to the Rev. H.C. Hopkins, she was "a worthy wife and mother; a devoted, honored, and dearly beloved maidservant of the Lord; and an ornament to the rectory and the congregation. Her commitment, tact, and ingenuity made her a popular, competent, and energizing conductress. The Mission weighed heavily on her heart and she was a faithful intercessor for the Lord's work."
    </p><p>The Rev. Stulting, Sr. (of Humansdorp), who had also lost his wife a few months earlier, led the memorial service on the afternoon of Tuesday, December 19, 1939, and spoke passionately of John 14:1 and Prov. 31:10. At the grave, tribute was pronounced by the elder Naas Kritzinger on behalf of the church council and by Mrs. P.B. Geldenhuys in the name of the <a href="/w/index.php?title=Vrouesendingbond&amp;action=edit&amp;redlink=1" class="new" title="Vrouesendingbond (page does not exist)">VSB</a> and Biduursusters (lay sister organizations). The congregation sisters laid a suitable stone between the church and the meeting hall.<sup id="cite_ref-8" class="reference"><a href="#cite_note-8">&#91;8&#93;</a></sup>
    </p>
    <h2><span class="mw-headline" id="The_Rev._Du_Toit_accepts_his_emeritus">The Rev. Du Toit accepts his emeritus</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=12" title="Edit section: The Rev. Du Toit accepts his emeritus">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <p>The weekend of May 25-26, 1941, the congregation members said goodbye to their longtime pastor, the longest-tenured in their history thus far. On Sunday morning, the Rev. Du Toit delivered a striking, practical farewell sermon to his packed church, recalling John 21:7: "It is the Lord who calls, uses, and rewards his servants."
    </p><p>On Monday afternoon, the next pastor came to Joubertina. As their farwell to the Rev. Du Toit, the church council recorded their appreciation for his "faithful services, courtesy, kindness, and helpfulness." For a number of years, he served on the Cape Church's important Mission and Synod Commissions, and the Rev. Hopkins predicted in 1957 that "his and his wife's names will live on in the mission in particular" in Joubertina.
    </p>
    <h2><span class="mw-headline" id="Sources">Sources</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=13" title="Edit section: Sources">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <ul><li>(af) Hanekom, Dr. T.N. 1952. <i>Die hoë toring. Die Ned. Geref. Kerk Otjiwarongo Gedenkboek (1902–1952)</i>. Otjiwarongo: NG Kerkraad.</li>
    <li>(af) <a href="/w/index.php?title=Henry_Charles_Hopkins&amp;action=edit&amp;redlink=1" class="new" title="Henry Charles Hopkins (page does not exist)">Hopkins, H.C.</a> 1957. <i>Gendenkboek by die goue jubileum van die Ned. Geref. Kerk Joubertina</i>. Joubertina: NG Kerkraad.</li>
    <li>(nl) <a href="/w/index.php?title=Gustave_Adolph_Maeder&amp;action=edit&amp;redlink=1" class="new" title="Gustave Adolph Maeder (page does not exist)">Maeder, the Rev. G.A.</a> and Zinn, Christian. 1917. <i>Ons Kerk Album</i>. Cape Town: Ons Kerk Album Maatschappij Bpkt.</li>
    <li>(af) <a href="/w/index.php?title=Phil_Olivier&amp;action=edit&amp;redlink=1" class="new" title="Phil Olivier (page does not exist)">Olivier, the Rev. P.L.</a> (compiler). 1952. <i>Ons gemeentelike feesalbum</i>. Cape Town andPretoria: N.G. Kerk-Uitgewers.</li>
    <li>(af) Van Niekerk, A.A.J. 1980. Barrydale 1880–1980. <i>Die geskiedenis van ’n kerk en ’n gemeenskap</i>. Barrydale: Die Feeskomitee.</li>
    <li>(af) <a href="/w/index.php?title=Johannes_Van_Wijk&amp;action=edit&amp;redlink=1" class="new" title="Johannes Van Wijk (page does not exist)">Van Wijk, the Rev. J.H.</a> and Geldenhuys, the Rev. Norval (chief compiler). 1959. <i>Jaarboek van die Nederduitse Gereformeerde Kerk 1960</i>. Cape Town: N.G. Kerk-Uitgewers.</li>
    <li>(af) Wiid, Rina. 2004. <i>150 jubeljare. 1854–2004</i>. Hopetown: NG Kerkraad.</li></ul>
    <h2><span class="mw-headline" id="References">References</span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit&amp;section=14" title="Edit section: References">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
    <div class="reflist" style="list-style-type: decimal;">
    <div class="mw-references-wrap"><ol class="references">
    <li id="cite_note-1"><span class="mw-cite-backlink"><b><a href="#cite_ref-1">^</a></b></span> <span class="reference-text"><cite class="citation book">Hopkins, H.C. (1957). <i>Gendenkboek by die goue jubileum van die Ned. Geref. Kerk Joubertina</i>. Joubertina: NG Kerkraad.</cite><span title="ctx_ver=Z39.88-2004&amp;rft_val_fmt=info%3Aofi%2Ffmt%3Akev%3Amtx%3Abook&amp;rft.genre=book&amp;rft.btitle=Gendenkboek+by+die+goue+jubileum+van+die+Ned.+Geref.+Kerk+Joubertina.&amp;rft.place=Joubertina&amp;rft.pub=NG+Kerkraad&amp;rft.date=1957&amp;rft.aulast=Hopkins&amp;rft.aufirst=H.C.&amp;rfr_id=info%3Asid%2Fen.wikipedia.org%3AMatthys+du+Toit" class="Z3988"></span><style data-mw-deduplicate="TemplateStyles:r886058088">.mw-parser-output cite.citation{font-style:inherit}.mw-parser-output .citation q{quotes:"\"""\"""'""'"}.mw-parser-output .citation .cs1-lock-free a{background:url("//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Lock-green.svg/9px-Lock-green.svg.png")no-repeat;background-position:right .1em center}.mw-parser-output .citation .cs1-lock-limited a,.mw-parser-output .citation .cs1-lock-registration a{background:url("//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Lock-gray-alt-2.svg/9px-Lock-gray-alt-2.svg.png")no-repeat;background-position:right .1em center}.mw-parser-output .citation .cs1-lock-subscription a{background:url("//upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Lock-red-alt-2.svg/9px-Lock-red-alt-2.svg.png")no-repeat;background-position:right .1em center}.mw-parser-output .cs1-subscription,.mw-parser-output .cs1-registration{color:#555}.mw-parser-output .cs1-subscription span,.mw-parser-output .cs1-registration span{border-bottom:1px dotted;cursor:help}.mw-parser-output .cs1-ws-icon a{background:url("//upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/12px-Wikisource-logo.svg.png")no-repeat;background-position:right .1em center}.mw-parser-output code.cs1-code{color:inherit;background:inherit;border:inherit;padding:inherit}.mw-parser-output .cs1-hidden-error{display:none;font-size:100%}.mw-parser-output .cs1-visible-error{font-size:100%}.mw-parser-output .cs1-maint{display:none;color:#33aa33;margin-left:0.3em}.mw-parser-output .cs1-subscription,.mw-parser-output .cs1-registration,.mw-parser-output .cs1-format{font-size:95%}.mw-parser-output .cs1-kern-left,.mw-parser-output .cs1-kern-wl-left{padding-left:0.2em}.mw-parser-output .cs1-kern-right,.mw-parser-output .cs1-kern-wl-right{padding-right:0.2em}</style></span>
    </li>
    <li id="cite_note-2"><span class="mw-cite-backlink"><b><a href="#cite_ref-2">^</a></b></span> <span class="reference-text"><cite class="citation book">Van Wijk, The Rev. J.H.; Geldenhuys, Norval (chief compiler) (1959). <i>Jaarboek van die Nederduitse Gereformeerde Kerk 1960</i>. Cape Town: N.G. Kerk-Uitgewers.</cite><span title="ctx_ver=Z39.88-2004&amp;rft_val_fmt=info%3Aofi%2Ffmt%3Akev%3Amtx%3Abook&amp;rft.genre=book&amp;rft.btitle=Jaarboek+van+die+Nederduitse+Gereformeerde+Kerk+1960&amp;rft.place=Cape+Town&amp;rft.pub=N.G.+Kerk-Uitgewers&amp;rft.date=1959&amp;rft.aulast=Van+Wijk&amp;rft.aufirst=The+Rev.+J.H.&amp;rft.au=Geldenhuys%2C+Norval+%28chief+compiler%29&amp;rfr_id=info%3Asid%2Fen.wikipedia.org%3AMatthys+du+Toit" class="Z3988"></span><link rel="mw-deduplicated-inline-style" href="mw-data:TemplateStyles:r886058088"/></span>
    </li>
    <li id="cite_note-3"><span class="mw-cite-backlink"><b><a href="#cite_ref-3">^</a></b></span> <span class="reference-text"><cite class="citation book">Van Niekerk, A.A.J. (1980). <i>Barrydale 1880–1980. Die geskiedenis van ’n kerk en ’n gemeenskap</i>. Barrydale: Die Feeskomitee.</cite><span title="ctx_ver=Z39.88-2004&amp;rft_val_fmt=info%3Aofi%2Ffmt%3Akev%3Amtx%3Abook&amp;rft.genre=book&amp;rft.btitle=Barrydale+1880%E2%80%931980.+Die+geskiedenis+van+%E2%80%99n+kerk+en+%E2%80%99n+gemeenskap&amp;rft.place=Barrydale&amp;rft.pub=Die+Feeskomitee&amp;rft.date=1980&amp;rft.aulast=Van+Niekerk&amp;rft.aufirst=A.A.J.&amp;rfr_id=info%3Asid%2Fen.wikipedia.org%3AMatthys+du+Toit" class="Z3988"></span><link rel="mw-deduplicated-inline-style" href="mw-data:TemplateStyles:r886058088"/></span>
    </li>
    <li id="cite_note-4"><span class="mw-cite-backlink"><b><a href="#cite_ref-4">^</a></b></span> <span class="reference-text"><cite class="citation book">Maeder, The Rev. G.A.; Zinn, Christian (1917). <i>Ons Kerk Album</i>. Cape Town: Ons Kerk Album Maatschappij Bpkt.</cite><span title="ctx_ver=Z39.88-2004&amp;rft_val_fmt=info%3Aofi%2Ffmt%3Akev%3Amtx%3Abook&amp;rft.genre=book&amp;rft.btitle=Ons+Kerk+Album&amp;rft.place=Cape+Town&amp;rft.pub=Ons+Kerk+Album+Maatschappij+Bpkt&amp;rft.date=1917&amp;rft.aulast=Maeder&amp;rft.aufirst=The+Rev.+G.A.&amp;rft.au=Zinn%2C+Christian&amp;rfr_id=info%3Asid%2Fen.wikipedia.org%3AMatthys+du+Toit" class="Z3988"></span><link rel="mw-deduplicated-inline-style" href="mw-data:TemplateStyles:r886058088"/></span>
    </li>
    <li id="cite_note-5"><span class="mw-cite-backlink"><b><a href="#cite_ref-5">^</a></b></span> <span class="reference-text"><cite class="citation book">Hanekom, Dr. T.N. (1952). <i>Die hoë toring. Die Ned. Geref. Kerk Otjiwarongo Gedenkboek (1902–1952)</i>. Otjiwarongo: NG Kerkraad.</cite><span title="ctx_ver=Z39.88-2004&amp;rft_val_fmt=info%3Aofi%2Ffmt%3Akev%3Amtx%3Abook&amp;rft.genre=book&amp;rft.btitle=Die+ho%C3%AB+toring.+Die+Ned.+Geref.+Kerk+Otjiwarongo+Gedenkboek+%281902%E2%80%931952%29&amp;rft.place=Otjiwarongo&amp;rft.pub=NG+Kerkraad&amp;rft.date=1952&amp;rft.aulast=Hanekom&amp;rft.aufirst=Dr.+T.N.&amp;rfr_id=info%3Asid%2Fen.wikipedia.org%3AMatthys+du+Toit" class="Z3988"></span><link rel="mw-deduplicated-inline-style" href="mw-data:TemplateStyles:r886058088"/></span>
    </li>
    <li id="cite_note-6"><span class="mw-cite-backlink"><b><a href="#cite_ref-6">^</a></b></span> <span class="reference-text"><cite class="citation book">Wiid, Rina (2004). <i>150 jubeljare. 1854–2004</i>. Hopetown: NG Kerkraad.</cite><span title="ctx_ver=Z39.88-2004&amp;rft_val_fmt=info%3Aofi%2Ffmt%3Akev%3Amtx%3Abook&amp;rft.genre=book&amp;rft.btitle=150+jubeljare.+1854%E2%80%932004&amp;rft.place=Hopetown&amp;rft.pub=NG+Kerkraad&amp;rft.date=2004&amp;rft.aulast=Wiid&amp;rft.aufirst=Rina&amp;rfr_id=info%3Asid%2Fen.wikipedia.org%3AMatthys+du+Toit" class="Z3988"></span><link rel="mw-deduplicated-inline-style" href="mw-data:TemplateStyles:r886058088"/></span>
    </li>
    <li id="cite_note-7"><span class="mw-cite-backlink"><b><a href="#cite_ref-7">^</a></b></span> <span class="reference-text"><cite class="citation web"><a rel="nofollow" class="external text" href="http://tweeriviere.net/?page_id=866">"Tweerivier 1765–2015"</a><span class="reference-accessdate">. Retrieved <span class="nowrap">16 September</span> 2016</span>.</cite><span title="ctx_ver=Z39.88-2004&amp;rft_val_fmt=info%3Aofi%2Ffmt%3Akev%3Amtx%3Abook&amp;rft.genre=unknown&amp;rft.btitle=Tweerivier+1765%E2%80%932015&amp;rft_id=http%3A%2F%2Ftweeriviere.net%2F%3Fpage_id%3D866&amp;rfr_id=info%3Asid%2Fen.wikipedia.org%3AMatthys+du+Toit" class="Z3988"></span><link rel="mw-deduplicated-inline-style" href="mw-data:TemplateStyles:r886058088"/></span>
    </li>
    <li id="cite_note-8"><span class="mw-cite-backlink"><b><a href="#cite_ref-8">^</a></b></span> <span class="reference-text"><cite class="citation book">Hopkins, H.C. (1957). <i>Gendenkboek by die goue jubileum van die Ned. Geref. Kerk Joubertina</i>. Joubertina: NG Kerkraad.</cite><span title="ctx_ver=Z39.88-2004&amp;rft_val_fmt=info%3Aofi%2Ffmt%3Akev%3Amtx%3Abook&amp;rft.genre=book&amp;rft.btitle=Gendenkboek+by+die+goue+jubileum+van+die+Ned.+Geref.+Kerk+Joubertina.&amp;rft.place=Joubertina&amp;rft.pub=NG+Kerkraad&amp;rft.date=1957&amp;rft.aulast=Hopkins&amp;rft.aufirst=H.C.&amp;rfr_id=info%3Asid%2Fen.wikipedia.org%3AMatthys+du+Toit" class="Z3988"></span><link rel="mw-deduplicated-inline-style" href="mw-data:TemplateStyles:r886058088"/></span>
    </li>
    </ol></div></div>
    <!-- 
    NewPP limit report
    Parsed by mw1322
    Cached time: 20190607005854
    Cache expiry: 2592000
    Dynamic content: false
    Complications: [vary‐revision]
    CPU time usage: 0.148 seconds
    Real time usage: 0.183 seconds
    Preprocessor visited node count: 417/1000000
    Preprocessor generated node count: 0/1500000
    Post‐expand include size: 9061/2097152 bytes
    Template argument size: 79/2097152 bytes
    Highest expansion depth: 7/40
    Expensive parser function count: 0/500
    Unstrip recursion depth: 1/20
    Unstrip post‐expand size: 21519/5000000 bytes
    Number of Wikibase entities loaded: 0/400
    Lua time usage: 0.086/10.000 seconds
    Lua memory usage: 2.42 MB/50 MB
    -->
    <!--
    Transclusion expansion time report (%,ms,calls,template)
    100.00%  146.175      1 Template:Reflist
    100.00%  146.175      1 -total
     82.53%  120.634      7 Template:Cite_book
      4.12%    6.029      1 Template:Cite_web
      2.19%    3.195      1 Template:Main_other
    -->
    
    <!-- Saved in parser cache with key enwiki:pcache:idhash:60590291-0!canonical and timestamp 20190607005854 and revision id 895176675
     -->
    </div><noscript><img src="//en.wikipedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1" style="border: none; position: absolute;" /></noscript></div>
    		
    		<div class="printfooter">Retrieved from "<a dir="ltr" href="https://en.wikipedia.org/w/index.php?title=Matthys_du_Toit&amp;oldid=895176675">https://en.wikipedia.org/w/index.php?title=Matthys_du_Toit&amp;oldid=895176675</a>"</div>
    		
    		<div id="catlinks" class="catlinks" data-mw="interface"><div id="mw-normal-catlinks" class="mw-normal-catlinks"><a href="/wiki/Help:Category" title="Help:Category">Categories</a>: <ul><li><a href="/wiki/Category:1874_births" title="Category:1874 births">1874 births</a></li><li><a href="/wiki/Category:1959_deaths" title="Category:1959 deaths">1959 deaths</a></li></ul></div></div>
    		
    		<div class="visualClear"></div>
    		
    	</div>
    </div>
    
    		<div id="mw-navigation">
    			<h2>Navigation menu</h2>
    			<div id="mw-head">
    									<div id="p-personal" role="navigation" aria-labelledby="p-personal-label">
    						<h3 id="p-personal-label">Personal tools</h3>
    						<ul>
    							<li id="pt-anonuserpage">Not logged in</li><li id="pt-anontalk"><a href="/wiki/Special:MyTalk" title="Discussion about edits from this IP address [n]" accesskey="n">Talk</a></li><li id="pt-anoncontribs"><a href="/wiki/Special:MyContributions" title="A list of edits made from this IP address [y]" accesskey="y">Contributions</a></li><li id="pt-createaccount"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=Matthys+du+Toit" title="You are encouraged to create an account and log in; however, it is not mandatory">Create account</a></li><li id="pt-login"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=Matthys+du+Toit" title="You&#039;re encouraged to log in; however, it&#039;s not mandatory. [o]" accesskey="o">Log in</a></li>						</ul>
    					</div>
    									<div id="left-navigation">
    										<div id="p-namespaces" role="navigation" class="vectorTabs" aria-labelledby="p-namespaces-label">
    						<h3 id="p-namespaces-label">Namespaces</h3>
    						<ul>
    							<li id="ca-nstab-main" class="selected"><span><a href="/wiki/Matthys_du_Toit" title="View the content page [c]" accesskey="c">Article</a></span></li><li id="ca-talk" class="new"><span><a href="/w/index.php?title=Talk:Matthys_du_Toit&amp;action=edit&amp;redlink=1" rel="discussion" title="Discussion about the content page (page does not exist) [t]" accesskey="t">Talk</a></span></li>						</ul>
    					</div>
    										<div id="p-variants" role="navigation" class="vectorMenu emptyPortlet" aria-labelledby="p-variants-label">
    												<input type="checkbox" class="vectorMenuCheckbox" aria-labelledby="p-variants-label" />
    						<h3 id="p-variants-label">
    							<span>Variants</span>
    						</h3>
    						<ul class="menu">
    													</ul>
    					</div>
    									</div>
    				<div id="right-navigation">
    										<div id="p-views" role="navigation" class="vectorTabs" aria-labelledby="p-views-label">
    						<h3 id="p-views-label">Views</h3>
    						<ul>
    							<li id="ca-view" class="collapsible selected"><span><a href="/wiki/Matthys_du_Toit">Read</a></span></li><li id="ca-edit" class="collapsible"><span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=edit" title="Edit this page [e]" accesskey="e">Edit</a></span></li><li id="ca-history" class="collapsible"><span><a href="/w/index.php?title=Matthys_du_Toit&amp;action=history" title="Past revisions of this page [h]" accesskey="h">View history</a></span></li>						</ul>
    					</div>
    										<div id="p-cactions" role="navigation" class="vectorMenu emptyPortlet" aria-labelledby="p-cactions-label">
    						<input type="checkbox" class="vectorMenuCheckbox" aria-labelledby="p-cactions-label" />
    						<h3 id="p-cactions-label"><span>More</span></h3>
    						<ul class="menu">
    													</ul>
    					</div>
    										<div id="p-search" role="search">
    						<h3>
    							<label for="searchInput">Search</label>
    						</h3>
    						<form action="/w/index.php" id="searchform">
    							<div id="simpleSearch">
    								<input type="search" name="search" placeholder="Search Wikipedia" title="Search Wikipedia [f]" accesskey="f" id="searchInput"/><input type="hidden" value="Special:Search" name="title"/><input type="submit" name="fulltext" value="Search" title="Search Wikipedia for this text" id="mw-searchButton" class="searchButton mw-fallbackSearchButton"/><input type="submit" name="go" value="Go" title="Go to a page with this exact name if it exists" id="searchButton" class="searchButton"/>							</div>
    						</form>
    					</div>
    									</div>
    			</div>
    			<div id="mw-panel">
    				<div id="p-logo" role="banner"><a class="mw-wiki-logo" href="/wiki/Main_Page" title="Visit the main page"></a></div>
    						<div class="portal" role="navigation" id="p-navigation" aria-labelledby="p-navigation-label">
    			<h3 id="p-navigation-label">Navigation</h3>
    			<div class="body">
    								<ul>
    					<li id="n-mainpage-description"><a href="/wiki/Main_Page" title="Visit the main page [z]" accesskey="z">Main page</a></li><li id="n-contents"><a href="/wiki/Portal:Contents" title="Guides to browsing Wikipedia">Contents</a></li><li id="n-featuredcontent"><a href="/wiki/Portal:Featured_content" title="Featured content – the best of Wikipedia">Featured content</a></li><li id="n-currentevents"><a href="/wiki/Portal:Current_events" title="Find background information on current events">Current events</a></li><li id="n-randompage"><a href="/wiki/Special:Random" title="Load a random article [x]" accesskey="x">Random article</a></li><li id="n-sitesupport"><a href="https://donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&amp;utm_medium=sidebar&amp;utm_campaign=C13_en.wikipedia.org&amp;uselang=en" title="Support us">Donate to Wikipedia</a></li><li id="n-shoplink"><a href="//shop.wikimedia.org" title="Visit the Wikipedia store">Wikipedia store</a></li>				</ul>
    							</div>
    		</div>
    			<div class="portal" role="navigation" id="p-interaction" aria-labelledby="p-interaction-label">
    			<h3 id="p-interaction-label">Interaction</h3>
    			<div class="body">
    								<ul>
    					<li id="n-help"><a href="/wiki/Help:Contents" title="Guidance on how to use and edit Wikipedia">Help</a></li><li id="n-aboutsite"><a href="/wiki/Wikipedia:About" title="Find out about Wikipedia">About Wikipedia</a></li><li id="n-portal"><a href="/wiki/Wikipedia:Community_portal" title="About the project, what you can do, where to find things">Community portal</a></li><li id="n-recentchanges"><a href="/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]" accesskey="r">Recent changes</a></li><li id="n-contactpage"><a href="//en.wikipedia.org/wiki/Wikipedia:Contact_us" title="How to contact Wikipedia">Contact page</a></li>				</ul>
    							</div>
    		</div>
    			<div class="portal" role="navigation" id="p-tb" aria-labelledby="p-tb-label">
    			<h3 id="p-tb-label">Tools</h3>
    			<div class="body">
    								<ul>
    					<li id="t-whatlinkshere"><a href="/wiki/Special:WhatLinksHere/Matthys_du_Toit" title="List of all English Wikipedia pages containing links to this page [j]" accesskey="j">What links here</a></li><li id="t-recentchangeslinked"><a href="/wiki/Special:RecentChangesLinked/Matthys_du_Toit" rel="nofollow" title="Recent changes in pages linked from this page [k]" accesskey="k">Related changes</a></li><li id="t-upload"><a href="/wiki/Wikipedia:File_Upload_Wizard" title="Upload files [u]" accesskey="u">Upload file</a></li><li id="t-specialpages"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q">Special pages</a></li><li id="t-permalink"><a href="/w/index.php?title=Matthys_du_Toit&amp;oldid=895176675" title="Permanent link to this revision of the page">Permanent link</a></li><li id="t-info"><a href="/w/index.php?title=Matthys_du_Toit&amp;action=info" title="More information about this page">Page information</a></li><li id="t-wikibase"><a href="https://www.wikidata.org/wiki/Special:EntityPage/Q31736577" title="Link to connected data repository item [g]" accesskey="g">Wikidata item</a></li><li id="t-cite"><a href="/w/index.php?title=Special:CiteThisPage&amp;page=Matthys_du_Toit&amp;id=895176675" title="Information on how to cite this page">Cite this page</a></li>				</ul>
    							</div>
    		</div>
    			<div class="portal" role="navigation" id="p-coll-print_export" aria-labelledby="p-coll-print_export-label">
    			<h3 id="p-coll-print_export-label">Print/export</h3>
    			<div class="body">
    								<ul>
    					<li id="coll-create_a_book"><a href="/w/index.php?title=Special:Book&amp;bookcmd=book_creator&amp;referer=Matthys+du+Toit">Create a book</a></li><li id="coll-download-as-rl"><a href="/w/index.php?title=Special:ElectronPdf&amp;page=Matthys+du+Toit&amp;action=show-download-screen">Download as PDF</a></li><li id="t-print"><a href="/w/index.php?title=Matthys_du_Toit&amp;printable=yes" title="Printable version of this page [p]" accesskey="p">Printable version</a></li>				</ul>
    							</div>
    		</div>
    			<div class="portal" role="navigation" id="p-lang" aria-labelledby="p-lang-label">
    			<h3 id="p-lang-label">Languages</h3>
    			<div class="body">
    								<ul>
    					<li class="interlanguage-link interwiki-af"><a href="https://af.wikipedia.org/wiki/Matthys_du_Toit" title="Matthys du Toit – Afrikaans" lang="af" hreflang="af" class="interlanguage-link-target">Afrikaans</a></li>				</ul>
    				<div class="after-portlet after-portlet-lang"><span class="wb-langlinks-edit wb-langlinks-link"><a href="https://www.wikidata.org/wiki/Special:EntityPage/Q31736577#sitelinks-wikipedia" title="Edit interlanguage links" class="wbc-editpage">Edit links</a></span></div>			</div>
    		</div>
    				</div>
    		</div>
    				<div id="footer" role="contentinfo">
    						<ul id="footer-info">
    								<li id="footer-info-lastmod"> This page was last edited on 2 May 2019, at 14:10<span class="anonymous-show">&#160;(UTC)</span>.</li>
    								<li id="footer-info-copyright">Text is available under the <a rel="license" href="//en.wikipedia.org/wiki/Wikipedia:Text_of_Creative_Commons_Attribution-ShareAlike_3.0_Unported_License">Creative Commons Attribution-ShareAlike License</a><a rel="license" href="//creativecommons.org/licenses/by-sa/3.0/" style="display:none;"></a>;
    additional terms may apply.  By using this site, you agree to the <a href="//foundation.wikimedia.org/wiki/Terms_of_Use">Terms of Use</a> and <a href="//foundation.wikimedia.org/wiki/Privacy_policy">Privacy Policy</a>. Wikipedia® is a registered trademark of the <a href="//www.wikimediafoundation.org/">Wikimedia Foundation, Inc.</a>, a non-profit organization.</li>
    							</ul>
    						<ul id="footer-places">
    								<li id="footer-places-privacy"><a href="https://foundation.wikimedia.org/wiki/Privacy_policy" class="extiw" title="wmf:Privacy policy">Privacy policy</a></li>
    								<li id="footer-places-about"><a href="/wiki/Wikipedia:About" title="Wikipedia:About">About Wikipedia</a></li>
    								<li id="footer-places-disclaimer"><a href="/wiki/Wikipedia:General_disclaimer" title="Wikipedia:General disclaimer">Disclaimers</a></li>
    								<li id="footer-places-contact"><a href="//en.wikipedia.org/wiki/Wikipedia:Contact_us">Contact Wikipedia</a></li>
    								<li id="footer-places-developers"><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute">Developers</a></li>
    								<li id="footer-places-cookiestatement"><a href="https://foundation.wikimedia.org/wiki/Cookie_statement">Cookie statement</a></li>
    								<li id="footer-places-mobileview"><a href="//en.m.wikipedia.org/w/index.php?title=Matthys_du_Toit&amp;mobileaction=toggle_view_mobile" class="noprint stopMobileRedirectToggle">Mobile view</a></li>
    							</ul>
    										<ul id="footer-icons" class="noprint">
    										<li id="footer-copyrightico">
    						<a href="https://wikimediafoundation.org/"><img src="/static/images/wikimedia-button.png" srcset="/static/images/wikimedia-button-1.5x.png 1.5x, /static/images/wikimedia-button-2x.png 2x" width="88" height="31" alt="Wikimedia Foundation"/></a>					</li>
    										<li id="footer-poweredbyico">
    						<a href="https://www.mediawiki.org/"><img src="/static/images/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/static/images/poweredby_mediawiki_132x47.png 1.5x, /static/images/poweredby_mediawiki_176x62.png 2x" width="88" height="31"/></a>					</li>
    									</ul>
    						<div style="clear: both;"></div>
    		</div>
    		
    
    <script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgPageParseReport":{"limitreport":{"cputime":"0.148","walltime":"0.183","ppvisitednodes":{"value":417,"limit":1000000},"ppgeneratednodes":{"value":0,"limit":1500000},"postexpandincludesize":{"value":9061,"limit":2097152},"templateargumentsize":{"value":79,"limit":2097152},"expansiondepth":{"value":7,"limit":40},"expensivefunctioncount":{"value":0,"limit":500},"unstrip-depth":{"value":1,"limit":20},"unstrip-size":{"value":21519,"limit":5000000},"entityaccesscount":{"value":0,"limit":400},"timingprofile":["100.00%  146.175      1 Template:Reflist","100.00%  146.175      1 -total"," 82.53%  120.634      7 Template:Cite_book","  4.12%    6.029      1 Template:Cite_web","  2.19%    3.195      1 Template:Main_other"]},"scribunto":{"limitreport-timeusage":{"value":"0.086","limit":"10.000"},"limitreport-memusage":{"value":2536002,"limit":52428800}},"cachereport":{"origin":"mw1322","timestamp":"20190607005854","ttl":2592000,"transientcontent":false}}});});</script>
    <script type="application/ld+json">{"@context":"https:\/\/schema.org","@type":"Article","name":"Matthys du Toit","url":"https:\/\/en.wikipedia.org\/wiki\/Matthys_du_Toit","sameAs":"http:\/\/www.wikidata.org\/entity\/Q31736577","mainEntity":"http:\/\/www.wikidata.org\/entity\/Q31736577","author":{"@type":"Organization","name":"Contributors to Wikimedia projects"},"publisher":{"@type":"Organization","name":"Wikimedia Foundation, Inc.","logo":{"@type":"ImageObject","url":"https:\/\/www.wikimedia.org\/static\/images\/wmf-hor-googpub.png"}},"datePublished":"2019-04-26T04:05:22Z","dateModified":"2019-05-02T14:10:45Z"}</script>
    <script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgBackendResponseTime":123,"wgHostname":"mw1239"});});</script>
    </body>
    </html>
    



```python
starttitle = page.find('<title>')
endtitle = page.find('</title>')
title = page[starttitle + 7 : endtitle]
print(title)
```

    Matthys du Toit - Wikipedia



```python
album_title = title.replace(' - Wikipedia', '')
print(album_title)
```

    Matthys du Toit


 Printing the band and album titles



```python
print("Your band: ", band_title)
print("Your album: ", album_title)
```

    Your band:  European Climate Foundation
    Your album:  Matthys du Toit


## 5. Displaying the Generated Album Cover


```python
# using the display_cover function to put the generated random title
# for the band and album names
img=display_cover(top=band_title, bottom=album_title)

# save the file to sample-out.png
img.save('sample-out.png')
```


```python
# display the saved file
IPythonImage(filename='sample-out.png')
```




![png](output_22_0.png)



## Credit and Inspiration

https://picsum.photos/





https://www.coursera.org/specializations/ibm-data-science-professional-certificate

https://cognitiveclass.ai/

https://fakealbumcovers.com/

https://www.reddit.com/r/fakealbumcovers/

## License

 The MIT License (MIT)

Copyright © 2019 <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.



```python

```
